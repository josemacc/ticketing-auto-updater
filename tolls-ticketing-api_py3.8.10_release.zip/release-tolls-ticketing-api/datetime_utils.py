from datetime import datetime, timezone
import pytz
import tolls_ticketing_proj.settings as settings


DATE_YYYY_MM_DD_FORMAT = '%Y%m%d'
weekdays = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo']
months = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
          'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']


def utc_now_tz():
    """
    Return current moment.

    :return: datetime. The timezone-aware datetime object of the moment this function was called.
             The timezone is set to UTC
    """
    return datetime.now(timezone.utc)


def get_date_from_str(date_str, datetime_format=DATE_YYYY_MM_DD_FORMAT, tz_name=settings.TIME_ZONE):
    """
    Parse a date representing a date and return the datetime object.

    :param date_str: str. The str representing the date to convert
    :param datetime_format: str. The date format to use when parsing the date str. It defaults to DATE_YYYY_MM_DD_FORMAT
    :param tz_name: str. The name of the timezone to the date str is on. It defaults to settings.TIME_ZONE
    :return: datetime. The timezone-aware datetime object
    """
    tz_info = pytz.timezone(tz_name)
    dt = datetime.strptime(date_str, datetime_format)
    new_dt = tz_info.localize(dt)
    return new_dt


def days_until_now(moment):
    """
    Return the days between just now and the provided datetime.

    :param moment: datetime. The moment to check against now
    :return: int. The number of days difference
    """
    if moment.tzinfo is None:
        tz_info = pytz.timezone(settings.TIME_ZONE)
        moment_tz = tz_info.localize(moment, False)
    else:
        moment_tz = moment

    days = (utc_now_tz() - moment_tz).days
    return days


def printable_datetime(datetime_value):
    date_format = '{{1}} %-d de {{2}}, %Y %H:%m:%S %p'
    weekday = weekdays[datetime_value.weekday()]
    month_name = months[datetime_value.month - 1]
    return datetime.now().strftime(date_format).replace('{{1}}', weekday).replace('{{2}}', month_name)
