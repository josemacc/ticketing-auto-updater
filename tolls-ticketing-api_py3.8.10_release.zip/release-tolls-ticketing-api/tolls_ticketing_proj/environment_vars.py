import sys
import os


DEFAULT_ENV_FILEPATH = '/etc/ticketing/api.env'


def import_env():
    use_env_file = os.environ.get('USE_ENV_FILE')

    try:
        env_filename = use_env_file or DEFAULT_ENV_FILEPATH
        with open(env_filename, 'rt') as f:
            for line in f:
                line = line.strip()
                if len(line) == 0 or line.startswith('#'):
                    continue

                parts = line.split('=', 1)
                if len(parts) > 0:
                    var_name = parts[0].strip()
                    var_value = parts[1].strip() if len(parts) >= 2 else ''
                    os.environ[var_name] = var_value

        import logging
    except Exception as e:
        import logging
        logging.error(f'Could not parse the environment variables. The exception is: {e}')


def update_path():
    remove_paths = os.environ.get('REMOVE_PATHS', '').split()
    add_paths = os.environ.get('ADD_PATHS', '').split()

    if remove_paths:
        for p_item in remove_paths:
            p_item = p_item.strip()
            if p_item and (p_item in sys.path):
                idx = sys.path.index(p_item)
                del sys.path[idx]

    if add_paths:
        for p_item in add_paths:
            p_item = p_item.strip()
            if p_item and (p_item not in sys.path):
                sys.path.append(p_item)
