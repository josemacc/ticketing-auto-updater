class TicketingException(Exception):
    """
    A custom Exception for Ticketing Tolls. This subclass allows us to provide a return_code and an optional reason.
    The "return_code" is any of the values in response_codes.py
    The "reason" is a description text of what variable or value failed the operation, this is optional.

    For example:

    data = look_up_some_data()
    if data is None:
      raise RegionalException(response_codes.OBJECT_NOT_FOUND, 'user data nonexistent')
    """
    return_code: str = None
    reason: str = None

    def __init__(self, return_code, reason=None):
        self.return_code = return_code
        self.reason = reason
        super().__init__()
