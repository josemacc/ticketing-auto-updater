import inspect
import time
import weakref
from queue import Queue, Empty
from threading import Event, Thread

from dispatcher_module.events import base_event as events
from dispatcher_module.event_dispatcher import messages, consts

from logger import get_logger
logger = get_logger()


class EventDispatcherThread:
    compiled_sources = []
    short_sleep_time = 1.5
    inbox_queue = Queue()
    _running_thread = None
    _stop_signal = None

    def __init__(self, module, event_inbox_queue=None):
        self.module = weakref.ref(module)
        self.name = f'{module.module_uid}_dispatcher'
        self.event_inbox_queue = event_inbox_queue
        self.is_valid_config = True

    def start(self):
        if not self.is_valid_config:
            return False

        if not isinstance(self.event_inbox_queue, Queue):
            logger.error(messages.NOT_A_QUEUE_FMT.format(self.name))
            return False

        if not self.is_running():
            self._stop_signal = Event()
            self._stop_signal.clear()

            self._running_thread = Thread(name=self.name, target=self.thread_worker, daemon=False)
            self._running_thread.start()
            time.sleep(0.05)

        else:
            logger.error(messages.MODULE_WAS_RUNNING_ALREADY_FMT.format(self.name))

        return self.is_running()

    def stop(self):
        if not self.is_valid_config:
            return

        if self.is_running():
            self._stop_signal.set()
            self._running_thread.join()
            self._running_thread = None
        else:
            logger.error(messages.MODULE_WAS_STOPPED_ALREADY_FMT.format(self.name))

    def is_running(self):
        return bool(self._running_thread and self._running_thread.is_alive()) and not self._stop_signal.is_set()

    def thread_worker(self):
        logger.debug(messages.WORKER_STARTED_FMT.format(self.name))

        while self.is_running():
            try:
                queue_event = self.event_inbox_queue.get(block=True, timeout=self.short_sleep_time)
                if isinstance(queue_event, events.BaseEvent):
                    mod = self.module() if isinstance(self.module, weakref.ref) else self.module
                    class_members = dict(inspect.getmembers(mod))
                    dispatch_method = class_members.get(consts.EVENT_DISPATCH_METHOD)
                    if dispatch_method:
                        initial_time = time.time_ns()
                        try:
                            dispatch_method(queue_event.get_and_log_event(self.name))
                            execution_time = time.time_ns() - initial_time
                            if execution_time > queue_event.long_time_execution:
                                logger.warning(f'Execution time exceeded for event "{queue_event.name}"')

                        except NotImplementedError:
                            logger.error(f'Method not implemented for event "{queue_event.name}"')
                    else:
                        logger.error(f'Method not defined for event "{queue_event.name}"')

            except Empty:
                pass

        logger.debug(messages.WORKER_STOPPED_FMT.format(self.name))
