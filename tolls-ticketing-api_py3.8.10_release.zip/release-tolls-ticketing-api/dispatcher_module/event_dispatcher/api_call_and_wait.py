from modules import post_event
from dispatcher_module.events.api_caller_events import ApiCallerEvent


def api_call_and_wait(api_name, params):
    from queue import Queue, Empty

    q = Queue()

    event_data = {
        'api': api_name,
        'return_queue': q,
        'params': params
    }

    post_event(ApiCallerEvent(None, event_data))

    success, result = False, None
    try:
        try:
            response = q.get(timeout=120)  # 2 min before timing out
        except Empty:
            response = None

        if response:
            success = response.get('success')
            result = response.get('response')

    except Empty:
        pass

    return success, result
