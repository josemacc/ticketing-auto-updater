REFERENCE = 'ref'
EVENT_DISPATCH_METHOD = 'do_dispatch_event'
REQUEST_DISPATCH_METHOD = 'do_dispatch_request'
