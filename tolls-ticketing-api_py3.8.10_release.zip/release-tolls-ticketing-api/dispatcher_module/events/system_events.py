from dispatcher_module.events.base_event import BaseEvent


class SystemStateEvent(BaseEvent):
    pass


class UpdateAppEvent(BaseEvent):
    pass
