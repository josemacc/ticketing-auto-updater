from dispatcher_module.events.base_event import BaseEvent


class GetAntennaMessage(BaseEvent):

    return_queue = None

    def __init__(self, return_queue=None):
        super().__init__()
        self.return_queue = return_queue


class SetAntennaMessage(BaseEvent):

    new_state = None
    return_queue = None

    def __init__(self, new_state, return_queue=None):
        super().__init__()
        self.new_state = new_state
        self.return_queue = return_queue
