import response_codes
from dispatcher_module.events.base_event import BaseEvent


class GetLicensePlate(BaseEvent):
    vehicle_category = None

    def __init__(self, vehicle_category):
        super().__init__()
        self.vehicle_category = vehicle_category


class ImageCapturedSuccess(BaseEvent):
    def __init__(self):
        super().__init__()


class ImageCapturedFail(BaseEvent):
    error_code = response_codes.UNEXPECTED_ERROR

    def __init__(self,  error_code: str):
        super().__init__()
        self.error_code = error_code
