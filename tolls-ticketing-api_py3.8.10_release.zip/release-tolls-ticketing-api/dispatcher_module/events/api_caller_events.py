from dispatcher_module.events.base_event import BaseEvent


class ApiCallerEvent(BaseEvent):
    pass
