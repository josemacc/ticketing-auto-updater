from dispatcher_module.events.base_event import BaseEvent


class GetGateState(BaseEvent):
    """
    Request current state for the gate. The response will be
    events.consts.GATE_STATE_OPEN, events.consts.GATE_STATE_CLOSE or events.consts.GATE_STATE_UNKNOWN
    """
    return_queue = None

    def __init__(self, return_queue=None):
        super().__init__()
        self.return_queue = return_queue


class SetGateState(BaseEvent):
    """
    Request a new state for the gate. It should be either
    events.consts.GATE_STATE_OPEN or events.consts.GATE_STATE_CLOSE
    """
    new_state = None
    return_queue = None

    def __init__(self, new_state, return_queue=None):
        super().__init__()
        self.new_state = new_state
        self.return_queue = return_queue
