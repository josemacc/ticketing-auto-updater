from dispatcher_module.events.base_event import BaseEvent


class StateMachineEvent(BaseEvent):
    pass


class StateMachineErrorEvent(BaseEvent):
    pass


class StateMachinePaymentProcessed(BaseEvent):
    payment_data = None

    def __init__(self, payment_data):
        super().__init__()
        self.payment_data = payment_data


class StateMachineEventPrintConfirmation(BaseEvent):
    print_request = None

    def __init__(self, print_request):
        super().__init__()
        self.print_request = print_request


class StateMachineCloseOperatorPeriod(BaseEvent):
    close_period_data = None

    def __init__(self, close_period_data):
        super().__init__()
        self.close_period_data = close_period_data


class StateMachineOperatorLogin(BaseEvent):
    def __init__(self):
        super().__init__()
