from dispatcher_module.events.base_event import BaseEvent
from .consts import VALID_PRINT_JOB_TYPES


class StateMachinePrinterIsDone(BaseEvent):
    status: str = None
    job_type: str = None

    def __init__(self, status: str, job_type: str):
        super().__init__()
        self.status = status
        self.job_type = job_type


class PrintJob(BaseEvent):
    print_job_type = None
    print_job_data = None

    def __init__(self, print_job_type, print_job_data):
        super().__init__()

        if print_job_type not in VALID_PRINT_JOB_TYPES:
            raise Exception('Invalid job type')

        self.print_job_data = print_job_data
        self.print_job_type = print_job_type


class StateMachinePrinterRetryOrCancel(BaseEvent):
    operation: str = None

    def __init__(self, operation: str):
        super().__init__()
        self.operation = operation
