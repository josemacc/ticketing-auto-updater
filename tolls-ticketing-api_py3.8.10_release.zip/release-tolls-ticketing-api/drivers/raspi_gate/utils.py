from queue import Queue, Empty
from typing import Optional

from dispatcher_module.events import gate_events
from common_consts import OPERATION_STATE__GET, OPERATION_STATE__SET
from modules import post_event


def gate_call_and_wait(operation: str, params: Optional[dict] = None):
    q = Queue()

    success = False
    return_code = None
    return_data = None

    if operation == OPERATION_STATE__GET:
        post_event(gate_events.GetGateState(return_queue=q))
    elif operation == OPERATION_STATE__SET:
        new_state = params.get('new_state') if type(params) == dict else None
        post_event(gate_events.SetGateState(new_state, return_queue=q))

    try:
        response = q.get()
        if response:
            success = response.get('success')
            return_code = response.get('return_code')
            return_data = response.get('return_data')

    except Empty:
        pass

    return success, return_code, return_data
