##########################################################
# Communicate with the Raspberry gate controller
# Send open/close command and retrieve current gate state
##########################################################
import time
import threading

from common_consts import OPERATION_STATE__GET
from drivers.raspi_gate.utils import gate_call_and_wait
from modules.base_module import BaseModule
from multipledispatch import dispatch

from dispatcher_module.events import gate_events
from dispatcher_module.events.consts import GATE_STATE_UNKNOWN, GATE_STATE_CLOSE, GATE_STATE_OPEN
import response_codes
from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait
from dispatcher_module.events import system_events

from logger import get_logger
from tolls_ticketing_proj import settings

logger = get_logger()


# TODO: ------------- move this to raspberry device.  something like api_call_and_wait but for device response
#  DONE- respond to GetGateStatus in the same way that api_call_and_wait
#  DONE- respond to SetGateStatus in the same way that api_call_and_wait
#  - a timer to request gate status in the device
#  - a semaphore to prevent calling a get while a set is in progress and viceversa

class RaspberryGateController(BaseModule):
    last_gate_state = GATE_STATE_UNKNOWN
    report_state_thread = None
    report_state_signal = None

    # noinspection PyUnusedLocal
    def __init__(self, name, uid, config):
        super().__init__(name, uid)

    @dispatch(gate_events.GetGateState)
    def get_gate_state_ev(self, gate_event):
        logger.info(f'gate_event={gate_event}')
        return_queue = gate_event.return_queue

        if return_queue:
            data = self.get_gate_state()
            return_queue.put(data)

    @dispatch(gate_events.SetGateState)
    def set_gate_state_ev(self, gate_event):
        # Capture and validate parameters

        new_state = gate_event.new_state
        data = self.set_gate_state(new_state)
        return_queue = gate_event.return_queue

        if return_queue:
            return_queue.put(data)

    def get_gate_state(self):
        logger.info(f'get_gate_state.....')
        return GATE_STATE_OPEN

    @staticmethod
    def set_gate_state(new_state):
        if settings.DISABLE_CONNECTION_DEVICE:
            success = True
            return_code = response_codes.SUCCESS
            return_data = None

        else:
            return_code = response_codes.UNEXPECTED_ERROR
            return_data = None

            if new_state == GATE_STATE_OPEN:
                trigger = 'cmd_open_gate'
            elif new_state == GATE_STATE_CLOSE:
                trigger = 'cmd_close_gate'
            else:
                trigger = None

            if trigger:
                params = {
                    'trigger': trigger,
                    'mode': 'open/close'
                }
                success, result = api_call_and_wait('gate_device/action', params)

            else:
                success = False
                result = None

            # Process the result
            if success:
                logger.info(f'Success in set_gate_state calling the device')

                if type(result) == dict:
                    return_code = result.get('return_code')
                    if not return_code:
                        logger.warning('Warning in set_gate_state: No return_code returned from the device')
                    else:
                        return_data = result.get('return_data')

            else:
                logger.error('Error in set_gate_state calling the device')

        return {
            'success': success,
            'return_code': return_code,
            'return_data': return_data,
        }

    def on_module_start(self):
        self.report_state_signal = threading.Event()
        self.report_state_thread = threading.Thread(target=self.report_state_worker, daemon=False)
        self.report_state_thread.start()
        return True

    def on_module_stop(self):
        self.report_state_signal.set()
        self.report_state_thread.join()

        self.report_state_signal = None
        self.report_state_thread = None
        return True

    def report_state_worker(self):
        check_state_interval = 1  # The check interval in seconds
        next_check_time = 0  # The time in the future to check again. It will be re-calculated every time
        logger.info(f'report_state_worker started...')

        while not self.report_state_signal.is_set():
            self.report_state_signal.wait(0.5)

            current_time = time.time()
            if current_time >= next_check_time:
                logger.info('check time!')
                # success, return_code, return_data = gate_call_and_wait(OPERATION_STATE__GET)
                success, return_code, return_data = self.get_gate_state()
                if success and return_code == response_codes.SUCCESS:
                    logger.info(f'gate return_data={return_data}')
                else:
                    self.last_gate_state = GATE_STATE_UNKNOWN
                    if success:
                        logger.warning(f'Unable to check gate state: return_code="{return_code}"')
                    else:
                        logger.warning(f'Unable to check gate state: no response')

                next_check_time = current_time + check_state_interval

            self.post_event(
                system_events.SystemStateEvent(self, {
                    'module': 'raspi_gate',
                    'data': {
                        'state': self.last_gate_state,
                    }
                }))

        logger.info(f'report_state_worker stopped')
