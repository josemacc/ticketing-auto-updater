TAG_SUCCESS = 'tag_success'
TAG_INVALID = 'tag_invalid'
NOT_TAG = 'no_tag'

