
from api.models.antenna_models import TicketingAntennaMessages
from drivers.raspi_antenna import consts

from logger import get_logger
logger = get_logger()


def set_antenna_message(antenna_message: str):

    ticketing_antenna_message = _get_object()
    ticketing_antenna_message.message = antenna_message
    ticketing_antenna_message.save()

    logger.info(f'Changed gate mode to "{antenna_message}"')


def get_antenna_message() -> str:

    ticketing_gate_mode = _get_object()
    return ticketing_gate_mode.message


def _get_object() -> TicketingAntennaMessages:
    ticketing_antenna_messages = TicketingAntennaMessages.objects.all().first()

    if ticketing_antenna_messages is None:
        ticketing_antenna_messages = TicketingAntennaMessages(message=consts.NOT_TAG)
        ticketing_antenna_messages.save()

    return ticketing_antenna_messages
