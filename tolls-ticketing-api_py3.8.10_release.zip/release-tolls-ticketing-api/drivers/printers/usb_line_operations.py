import os.path
from datetime import datetime
from typing import Union, Optional

# noinspection PyPackageRequirements
from escpos.constants import QR_ECLEVEL_L
# noinspection PyPackageRequirements
from escpos.exceptions import USBNotFoundError
# noinspection PyPackageRequirements
from escpos.printer import Usb as EscPosUsbPrinter

import common_consts
import response_codes
from common_consts import VENEZUELAN_VES_ISO_CODE, DOLLAR_USD_ISO_CODE, COLOMBIAN_PESO_ISO_CODE, \
    CASH_METHOD, DEBIT_CREDIT_METHOD
from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait

from runtime_cache import consts as runtime_const
from runtime_cache import runtime_data_cache
from tolls_ticketing_proj import settings
from utils_accents import transform_tildes_if_needed

from logger import get_logger
logger = get_logger()


def init_and_print_header(p):
    logo = os.path.join(settings.TEMPLATES_BASE_DIR, settings.COMPANY_LOGO)
    company_info = runtime_data_cache.get_variable(runtime_const.COMPANY_INFO)

    # TODO: Extract the NIF/RIF from the Company Info in the login app_settings
    #   Check it is being sent already. Implement it on the Regional if not done
    company_rif = settings.COMPANY_RIF
    company_info['nif'] = company_rif
    company_info['name'] = settings.RECEIPT_COMPANY or company_info.get('name')

    if len(company_info.get('name')) > 27:
        company_info['name1'] = company_info.get('name')[0:27]
        company_info['name2'] = company_info.get('name')[27:]

    p.hw('INIT')
    p.set(align='center')
    p.image(logo)

    p.set(align='center', bold=True)
    p.textln(company_info.get('name1') or company_info.get('name'))
    p.textln(company_info.get('name2') or '')

    p.set(align='center')
    p.textln(company_info.get('nif'))
    p.ln()

    # Print the date
    now_str = datetime.now().strftime("%d/%m/%Y, %H:%M:%S")
    p.set(align='right')
    p.textln(now_str)


def get_general_info():
    toll_site_info = runtime_data_cache.get_variable(runtime_const.TOLL_SITE_INFO)
    if type(toll_site_info) == dict:
        toll_site_name = toll_site_info.get('name')
    else:
        toll_site_name = ''

    node_info = runtime_data_cache.get_variable(runtime_const.NODE_INFO)
    if type(node_info) == dict:
        node_name = node_info.get('name')
    else:
        node_name = ''

    lane_info = runtime_data_cache.get_variable(runtime_const.LANE_INFO)
    if type(lane_info) == dict:
        lane_name = lane_info.get('name')
    else:
        lane_name = ''

    return toll_site_name, node_name, lane_name


def generate_and_print_sale_receipt(id_vendor, id_product, out_ep, print_data: Union[dict, list]):
    try:
        p = EscPosUsbPrinter(idVendor=id_vendor, idProduct=id_product, out_ep=out_ep)

        disable_inverse_color = settings.DISABLE_RECEIPT_BLACK_BACKGROUND

        toll_site_name, node_name, lane_name = get_general_info()

        is_flat_data = type(print_data) == list

        if is_flat_data:
            for line in print_data:
                p.textln(line)

        else:

            phone_number = print_data['phone_number']
            ticket_no = print_data['ticket']
            operator_name = print_data['operator_info']
            fare_name = print_data['fare_name']
            car_weight = print_data['car_weight']
            payment_method = print_data['payment_method']
            total_amount = print_data['total_amount']

            init_and_print_header(p)

            p.textln(f'        Recibo#{ticket_no}')

            if toll_site_name:
                # Print the site name if it is defined
                p.text(f'Peaje:{toll_site_name}')

            p.textln(f'     {lane_name}')
            p.textln(f'Operador:{operator_name}')

            p.text(f'{fare_name}')
            if car_weight:
                # Print the car weight only for fares that use it
                p.text(f'     Peso:{car_weight}')

            p.textln(f'      {payment_method}')
            p.set(align='center', bold=True, invert=not disable_inverse_color, double_width=disable_inverse_color)
            p.textln(f'Monto: {total_amount}Bs')

            p.set(align='left', font="b")
            p.text(f'{node_name}')
            if phone_number:
                p.textln(f'         {phone_number}')
            else:
                p.ln()

            # Print the QR code
            keys_to_remove_qr = ['phone_number', 'car_weight', 'company_info', 'has_weight_factor', 'base_amount']
            qr_str = ''
            for k, v in print_data.items():
                if k not in keys_to_remove_qr and print_data[k]:
                    qr_str += f'{k}={print_data[k]}|'

            if qr_str:
                if qr_str.endswith('|'):
                    qr_str = qr_str[:-1]
                p.set(align='center')
                p.qr(qr_str, ec=QR_ECLEVEL_L, size=3, center=True)
            p.cut()
            p.close()

        return_code = response_codes.PRINTER_IDLE

    except USBNotFoundError:
        logger.info(f'Error in generate_and_print_receipt: Printer not connected')
        return_code = response_codes.PRINTER_NOT_CONNECTED

    except Exception as ex:
        logger.info(f'Error in generate_and_print_receipt: {ex}')
        return_code = response_codes.PRINTER_UNKNOWN_ERROR

    return return_code


def generate_and_print_close_period_receipt(id_vendor, id_product, out_ep, print_data: Union[dict, list]):
    try:
        toll_site_name, node_name, lane_name = get_general_info()
        operator_info = (runtime_data_cache.get_variable(runtime_const.OPERATOR_INFO) or {}).get('first_name')

        p = EscPosUsbPrinter(idVendor=id_vendor, idProduct=id_product, out_ep=out_ep)
        init_and_print_header(p)

        is_flat_data = type(print_data) == list

        gate_counters = get_counters_from_gate()

        if is_flat_data:
            p.set(align='left')
            for line in print_data:
                p.textln(line)

        else:
            operator = operator_info
            shift = print_data['shift_id']
            period = print_data['period_id']
            site = print_data.get('site') or toll_site_name
            lane = print_data.get('lane') or lane_name

            payments_by_method = print_data['data_by_payment_method']
            operator_data_payment = print_data['operator_data_payment']

            logger.info(f'======== close period data: payments_by_method="{payments_by_method}",'
                        f'operator_data_payment="{operator_data_payment}"')

            def payments_amount_n_count(iso_code: str) -> (float, float):
                if type(payments_by_method) == dict and iso_code in payments_by_method:
                    amount_n_count = payments_by_method[iso_code]
                    return amount_n_count['amount'], amount_n_count['count']

                return '-', 0

            def operator_form_amount(payment_type: str, iso_code: str) -> (float, float):
                payments_of_type = operator_data_payment.get(payment_type, {})

                if type(payments_of_type) == dict and iso_code in payments_of_type:
                    return payments_of_type[iso_code]

                return '-'

            amount_cash, count_cash = payments_amount_n_count('cash')
            amount_debit_credit, count_debit_credit = payments_amount_n_count('debit/credit')
            amount_post_payment, count_post_payment = payments_amount_n_count('post-payment')

            form_bs = operator_form_amount(CASH_METHOD, VENEZUELAN_VES_ISO_CODE)
            form_usd = operator_form_amount(CASH_METHOD, DOLLAR_USD_ISO_CODE)
            form_cop = operator_form_amount(CASH_METHOD, COLOMBIAN_PESO_ISO_CODE)
            form_debit = operator_form_amount(DEBIT_CREDIT_METHOD, VENEZUELAN_VES_ISO_CODE)

            p.set(align='right', bold=True, font='b')
            p.textln('Cierre de Turno')

            p.set(align='right', font='b')
            p.textln(transform_tildes_if_needed(f'Peaje: {site}'))
            p.textln(transform_tildes_if_needed(f'Canal: {lane}'))
            p.textln(transform_tildes_if_needed(f'Operador: {operator}'))
            p.textln(transform_tildes_if_needed(f'Turno/Período: {shift}/{period}'))
            p.textln('-----------------')
            p.set(align='left', font='b')

            if gate_counters:
                p.textln(transform_tildes_if_needed(f'Contador de vehículos:'))
                for item in gate_counters:
                    mode_count = item.get('name')
                    count_vehicle = item.get('vehicle_count')
                    mode_translate = common_consts.DICT_TRANSLATE.get(mode_count) or mode_count
                    p.textln(transform_tildes_if_needed(f'Pase {mode_translate}: {count_vehicle}'))

            p.textln('-----------------')
            p.set(align='left', font='b')
            p.textln('Ingresos (Efectivo):')
            p.textln(f'Bs. {amount_cash}')
            p.textln(f'Operaciones: {count_cash}')

            p.textln('-----------------')
            p.textln(transform_tildes_if_needed('Ingresos (Débito/Crédito):'))
            p.textln(f'Bs. {amount_debit_credit}')
            p.textln(f'Operaciones: {count_debit_credit}')

            p.textln('-----------------')
            p.textln('Ingresos (Post Pagos):')
            p.textln(f'Bs. {amount_post_payment}')
            p.textln(f'Operaciones: {count_post_payment}')

            p.set(align='left', font='b')
            p.textln('-----------------')
            p.textln('Ingresos de cierre:')
            p.textln(f'Bs: {form_bs}')
            p.textln(f'USD: {form_usd}')
            p.textln(f'COP: {form_cop}')
            p.textln(transform_tildes_if_needed(f'Débito/Crédito: {form_debit}'))

            p.cut()
            p.close()

        return_code = response_codes.PRINTER_IDLE

    except USBNotFoundError:
        logger.info(f'Error in generate_and_print_close_period_receipt: Printer not connected')
        return_code = response_codes.PRINTER_NOT_CONNECTED

    except Exception as ex:
        logger.info(f'Error in generate_and_print_close_period_receipt: {ex}')
        return_code = response_codes.PRINTER_UNKNOWN_ERROR

    return return_code


def get_counters_from_gate() -> Optional[list]:
    if settings.DISABLE_CONNECTION_DEVICE:
        return None

    return_code = response_codes.UNEXPECTED_ERROR
    counter_items = None

    try:
        params = {}
        success, result = api_call_and_wait('gate_device/counters', params)
        if success:
            if type(result) == dict:
                return_code = result.get('return_code')
                if not return_code:
                    return_code = response_codes.UNEXPECTED_ERROR
                    logger.warning('Warning in get_counter_value: No return_code returned from the device')

        if return_code == response_codes.SUCCESS:
            counter_items = result.get('counters')
        else:
            counter_items = [{'name': 'S/M', 'vehicle_count': 'S/I'}]
            logger.error(f'Error calling de Gate device to get count: return_code="{return_code}"')

    except Exception as ex:
        logger.error(f'Error in get_counter_value: {ex}')

    return counter_items
