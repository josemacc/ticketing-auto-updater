import json
import threading
from multipledispatch import dispatch
import time
from django.contrib.auth.models import User

import response_codes
from api.models.offline_mode_models import PrintedReceipts
from common_consts import PRINTER_STATUS_KEY, VALUES_FOR_TRUE
from dispatcher_module.events.consts import VALID_PRINT_JOB_TYPES, PRINT_JOB_TYPE_SALE, PRINT_JOB_TYPE_CLOSE_PERIOD
from modules.base_module import BaseModule
from dispatcher_module.events import system_events, printer_events
from tolls_ticketing_proj import settings
from runtime_cache import consts as runtime_const
from runtime_cache import runtime_data_cache

from .base_printer import BasePrinter
from . import operations

from logger import get_logger
logger = get_logger()


class PrinterDevice(BaseModule):
    print_job_data = None
    print_job_type = None
    print_job_response_code = None

    print_job_thread = None
    print_job_signal = None
    printer_buffer = None
    printer_usb = None

    hardware_printer: BasePrinter = None
    id_vendor: int = None
    id_product: int = None
    out_ep: int = None
    use_styles: bool = False

    def __init__(self, name, uid, config):
        super().__init__(name, uid)
        self.use_styles = bool(config.get('useStyles')) in VALUES_FOR_TRUE

        if settings.SIMULATED_PRINTER:
            from .simulated_printer import SimulatedPrinter
            self.hardware_printer = SimulatedPrinter()
        else:
            id_vendor = config.get('idVendor')
            id_product = config.get('idProduct')
            out_ep = config.get('out_ep')

            if not id_vendor:
                raise Exception('id_vendor not defined')
            try:
                self.id_vendor = int(id_vendor, 16)
            except Exception:
                raise Exception('id_vendor is not a hex value (eg,  0x821a)')

            if not id_product:
                raise Exception('id_product not defined')
            try:
                self.id_product = int(id_product, 16)
            except Exception:
                raise Exception('id_product is not a hex value (eg,  0x55ff)')

            if out_ep is not None:
                try:
                    self.out_ep = int(out_ep, 16)
                except Exception:
                    raise Exception('out_ep is not a hex value (eg,  0x01)')
            else:
                self.out_ep = 0x01

            from .usb_line_printer import UsbLinePrinter
            self.hardware_printer = UsbLinePrinter(self.id_vendor, self.id_product, self.out_ep)

    @dispatch(printer_events.PrintJob)
    def do_dispatch_event(self, app_event: printer_events.PrintJob):
        thread_is_alive = self.print_job_thread and self.print_job_thread.is_alive()
        if self.print_job_data or thread_is_alive:
            logger.error(f'Trying to print a new job while the previous one is still on going')
            self.post_event(printer_events.StateMachinePrinterIsDone(response_codes.PRINTER_BUSY, self.print_job_type))
            return

        # prepare the data
        print_job_type = app_event.print_job_type
        if print_job_type == PRINT_JOB_TYPE_SALE:
            print_data = operations.get_print_data(app_event.print_job_data)
        elif print_job_type == PRINT_JOB_TYPE_CLOSE_PERIOD:
            print_data = app_event.print_job_data
        else:
            print_data = None

        if print_data is not None and print_job_type in VALID_PRINT_JOB_TYPES:
            self.print_job_data = print_data
            self.print_job_type = print_job_type

        else:
            self.print_job_data = ['*** Se produjo un error generando ',
                                   'el recibo de la venta.',
                                   ' ',
                                   'Por favor, contacta a nuestros servicios ',
                                   'técnicos para corregir el problema. ',
                                   ' ',
                                   'En los registros (Logs) de la aplicación ',
                                   'hay más información que puede ser de ',
                                   'utilidad a nuestro equipo de ingenieros.',
                                   ' ',
                                   ]

        employee_info = runtime_data_cache.get_variable(runtime_const.OPERATOR_INFO)
        username = employee_info.get('username') if type(employee_info) == dict else None
        try:
            user = User.objects.get(username=username) if username else None
        except Exception as ex:
            logger.error(f'Error in printer_device.do_dispatch_event while getting the django user: {ex}')
            user = None

        try:
            job_data = json.dumps(self.print_job_data, default=str)
            job_type = self.print_job_type
            printed_receipt = PrintedReceipts(user=user, job_data=job_data, job_type=job_type)
            printed_receipt.save()
        except Exception as ex:
            logger.error(f'Error in printer_device.do_dispatch_event while saving the printed receipt: {ex}')

        # start the new print job
        self.print_job_signal = threading.Event()
        self.print_job_thread = threading.Thread(target=self.print_job_worker, daemon=True)
        self.print_job_thread.start()

    def print_job_worker(self):
        logger.info(f'Start print job {self.print_job_type} ...')

        status = response_codes.PRINTER_BUSY
        self.report_status(status)
        time.sleep(0.5)

        for status in self.hardware_printer.print_data(self.print_job_type, self.print_job_data):
            if self.print_job_signal.is_set():
                break

            time.sleep(0.1)

        message = response_codes.error_description(status)
        logger.info(f'Print job finished with status: {message} ({status})')
        self.report_status(status)
        self.post_event(printer_events.StateMachinePrinterIsDone(status, self.print_job_type))

        # clear the print job
        time.sleep(0.05)
        self.print_job_data = None

    def report_status(self, status):
        self.post_event(
            system_events.SystemStateEvent(self, {
                'module': 'printer',
                'data': {
                    PRINTER_STATUS_KEY: status,
                }
            }))

        return status
