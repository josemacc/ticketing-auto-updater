from typing import Optional

import response_codes
from dispatcher_module.events.consts import PRINT_JOB_TYPE_SALE, PRINT_JOB_TYPE_CLOSE_PERIOD
from .base_printer import BasePrinter
from .usb_line_operations import generate_and_print_sale_receipt, generate_and_print_close_period_receipt

from logger import get_logger
logger = get_logger()


class UsbLinePrinter(BasePrinter):
    status = response_codes.PRINTER_IDLE
    id_vendor = None
    id_product = None
    out_ep = None

    def __init__(self, id_vendor, id_product, out_ep):
        self.id_vendor = id_vendor
        self.id_product = id_product
        self.out_ep = out_ep or 0x01

    def check_status(self) -> str:
        return self.status

    def print_data(self, job_type: str, data: Optional[dict]):
        if data:
            self.status = response_codes.PRINTER_BUSY
            yield self.status

            if job_type == PRINT_JOB_TYPE_SALE:
                self.status = generate_and_print_sale_receipt(self.id_vendor, self.id_product, self.out_ep, data)

            elif job_type == PRINT_JOB_TYPE_CLOSE_PERIOD:
                self.status = generate_and_print_close_period_receipt(self.id_vendor,
                                                                      self.id_product, self.out_ep, data)
            else:
                self.status = response_codes.INVALID_REQUEST_PARAMETERS

            yield self.status

            if self.status != response_codes.PRINTER_IDLE:
                logger.error(f'Error in print_data: return_code="{self.status}"')
