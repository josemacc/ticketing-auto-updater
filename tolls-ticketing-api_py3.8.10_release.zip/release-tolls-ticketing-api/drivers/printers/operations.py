from typing import Optional

from api.models.print_models import NumTicket
from runtime_cache import runtime_data_cache
from runtime_cache import consts as runtime_const
from common_consts import FARE_PRODUCTS_KEY, PAYMENT_METHODS_STR

from logger import get_logger
logger = get_logger()


def get_print_data(payment_data) -> Optional[dict]:
    car_category = None
    nominal_amount = None
    fare_name = None

    try:
        node_info = runtime_data_cache.get_variable(runtime_const.NODE_INFO) or {}

        node_name = node_info.get('name', '???')
        phone_number = node_info.get('phone_1')
        company_info = runtime_data_cache.get_variable(runtime_const.COMPANY_INFO) or {}
        fare_products = runtime_data_cache.get_variable(FARE_PRODUCTS_KEY) or []
        lane_info = (runtime_data_cache.get_variable(runtime_const.LANE_INFO) or {}).get('name', '???')
        operator_info = (runtime_data_cache.get_variable(runtime_const.OPERATOR_INFO) or {}).get('first_name')

        create_num_ticket()
        ticket = plus_ticket()
        for idx in range(len(fare_products)):
            if payment_data['fare_product_id'] == fare_products[idx]['id']:
                car_category = fare_products[idx]['category']['title']
                nominal_amount = fare_products[idx]['nominal_amount']
                fare_name = fare_products[idx]['fare_name']
                break

        base_amount = nominal_amount
        payment_method = PAYMENT_METHODS_STR.get(payment_data['payment_method']) or '???'

        has_weight_factor = 'vehicle_weight' in payment_data
        if has_weight_factor:
            car_weight = str(payment_data['vehicle_weight']) + ' Kg'
            total_amount = payment_data['weight_factor_payment']

        else:
            car_weight = None
            total_amount = base_amount

        dict_data = {
            'node_name': node_name,
            'phone_number': phone_number,
            'company_info': company_info,
            'operator_info': operator_info,
            'lane_info': lane_info,
            'ticket': ticket,

            'car_category': car_category,
            'fare_name': fare_name,

            'car_weight': car_weight,
            'has_weight_factor': has_weight_factor,

            'base_amount': base_amount,
            'total_amount': total_amount,
            'payment_method': payment_method
        }

        return dict_data

    except Exception as ex:
        logger.error(f'Error in get_print_data: {ex}')
        return None


def create_num_ticket():
    try:
        NumTicket.objects.get(ticket='ticket')
    except Exception as e:
        logger.info(f'Ticketing number not found, generating a new sequence: {e}')
        ticket = NumTicket.objects.create()
        ticket.ticket = 'ticket'
        ticket.save()


def plus_ticket():
    num_ticket = NumTicket.objects.get(ticket='ticket')
    num_ticket.n_ticket = num_ticket.n_ticket + 1
    num_ticket.save()
    return num_ticket.n_ticket
