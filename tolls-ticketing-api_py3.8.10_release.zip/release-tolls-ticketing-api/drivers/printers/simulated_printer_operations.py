import os.path
from datetime import datetime
from typing import Union

import response_codes
from common_consts import VENEZUELAN_VES_ISO_CODE, DOLLAR_USD_ISO_CODE, COLOMBIAN_PESO_ISO_CODE, \
    CASH_METHOD, DEBIT_CREDIT_METHOD

from runtime_cache import consts as runtime_const
from runtime_cache import runtime_data_cache
from tolls_ticketing_proj import settings
from utils_accents import transform_tildes_if_needed

from logger import get_logger
logger = get_logger()


def init_and_print_header(p):
    logo = os.path.join(settings.TEMPLATES_BASE_DIR, settings.COMPANY_LOGO)
    company_info = runtime_data_cache.get_variable(runtime_const.COMPANY_INFO)

    # TODO: Extract the NIF/RIF from the Company Info in the login app_settings
    #   Check it is being sent already. Implement it on the Regional if not done
    company_rif = settings.COMPANY_RIF
    company_info['nif'] = company_rif

    p.hw('INIT')
    p.set(align='center')
    p.image(logo)

    p.set(align='center', bold=True)
    p.textln(company_info.get('name'))

    p.set(align='center')
    p.textln(company_info.get('nif'))
    p.ln()

    # Print the date
    now_str = datetime.now().strftime("%d/%m/%Y, %H:%M:%S")
    p.set(align='right')
    p.textln(now_str)


def get_general_info():
    toll_site_info = runtime_data_cache.get_variable(runtime_const.TOLL_SITE_INFO)
    if type(toll_site_info) == dict:
        toll_site_name = toll_site_info.get('name')
    else:
        toll_site_name = ''

    node_info = runtime_data_cache.get_variable(runtime_const.NODE_INFO)
    if type(node_info) == dict:
        node_name = node_info.get('name')
    else:
        node_name = ''

    lane_info = runtime_data_cache.get_variable(runtime_const.LANE_INFO)
    if type(lane_info) == dict:
        lane_name = lane_info.get('name')
    else:
        lane_name = ''

    return toll_site_name, node_name, lane_name


# noinspection PyUnusedLocal
def generate_and_print_sale_receipt(id_vendor, id_product, out_ep, print_data: Union[dict, list]):
    try:
        p = SimulatedPosPrinter()

        toll_site_name, node_name, lane_name = get_general_info()

        is_flat_data = type(print_data) == list

        if is_flat_data:
            for line in print_data:
                p.textln(line)

        else:

            phone_number = print_data['phone_number']
            ticket_no = print_data['ticket']
            operator_name = print_data['operator_info']
            fare_name = print_data['fare_name']
            car_weight = print_data['car_weight']
            payment_method = print_data['payment_method']
            total_amount = print_data['total_amount']

            init_and_print_header(p)

            p.textln(f'        Recibo#{ticket_no}')

            if toll_site_name:
                # Print the site name if it is defined
                p.text(f'Peaje:{toll_site_name}')

            p.textln(f'     {lane_name}')
            p.textln(f'Operador:{operator_name}')

            p.text(f'{fare_name}')
            if car_weight:
                # Print the car weight only for fares that use it
                p.text(f'     Peso:{car_weight}')

            p.textln(f'      {payment_method}')
            p.set(align='center', bold=True, invert=True)
            p.textln(f'  Monto: {total_amount} Bs  ')
            p.set(align='left', font="b")
            p.text(f'{node_name}')
            if phone_number:
                p.textln(f'         {phone_number}')
            else:
                p.ln()

            # Print the QR code
            keys_to_remove_qr = ['phone_number', 'car_weight', 'company_info', 'has_weight_factor', 'base_amount']
            qr_str = ''
            for k, v in print_data.items():
                if k not in keys_to_remove_qr and print_data[k]:
                    qr_str += f'{k}={print_data[k]}|'

            if qr_str:
                if qr_str.endswith('|'):
                    qr_str = qr_str[:-1]
                p.set(align='center')
                p.qr(qr_str)
            p.cut()
            p.close()

        return_code = response_codes.PRINTER_IDLE

    except Exception as ex:
        logger.info(f'Error in generate_and_print_receipt (SIMULATED): {ex}')
        return_code = response_codes.PRINTER_UNKNOWN_ERROR

    return return_code


# noinspection PyUnusedLocal
def generate_and_print_close_period_receipt(id_vendor, id_product, out_ep, print_data: Union[dict, list]):
    try:
        toll_site_name, node_name, lane_name = get_general_info()
        operator_info = (runtime_data_cache.get_variable(runtime_const.OPERATOR_INFO) or {}).get('first_name')

        p = SimulatedPosPrinter()
        init_and_print_header(p)

        is_flat_data = type(print_data) == list

        if is_flat_data:
            p.set(align='left')
            for line in print_data:
                p.textln(line)

        else:
            operator = operator_info
            shift = print_data['shift_id']
            period = print_data['period_id']
            site = print_data.get('site') or toll_site_name
            lane = print_data.get('lane') or lane_name

            payments_by_method = print_data['data_by_payment_method']
            operator_data_payment = print_data['operator_data_payment']

            logger.info(f'======== close period data: payments_by_method="{payments_by_method}",'
                        f'operator_data_payment="{operator_data_payment}"')

            def payments_amount_n_count(iso_code: str) -> (float, float):
                if type(payments_by_method) == dict and iso_code in payments_by_method:
                    amount_n_count = payments_by_method[iso_code]
                    return amount_n_count['amount'], amount_n_count['count']

                return 0, 0

            def operator_form_amount(payment_type: str, iso_code: str) -> (float, float):
                payments_of_type = operator_data_payment.get(payment_type, {})

                if type(payments_of_type) == dict and iso_code in payments_of_type:
                    return payments_of_type[iso_code]

                return 0, 0

            amount_cash, count_cash = payments_amount_n_count('cash')
            amount_debit_credit, count_debit_credit = payments_amount_n_count('debit/credit')
            amount_post_payment, count_post_payment = payments_amount_n_count('post-payment')

            form_bs = operator_form_amount(CASH_METHOD, VENEZUELAN_VES_ISO_CODE)
            form_usd = operator_form_amount(CASH_METHOD, DOLLAR_USD_ISO_CODE)
            form_cop = operator_form_amount(CASH_METHOD, COLOMBIAN_PESO_ISO_CODE)
            form_debit = operator_form_amount(DEBIT_CREDIT_METHOD, VENEZUELAN_VES_ISO_CODE)

            p.set(align='right', bold=True, font='b')
            p.textln('Cierre de Turno')

            p.set(align='right', font='b')
            p.textln(transform_tildes_if_needed(f'Peaje: {site}'))
            p.textln(transform_tildes_if_needed(f'Canal: {lane}'))
            p.textln(transform_tildes_if_needed(f'Operador: {operator}'))
            p.textln(transform_tildes_if_needed(f'Turno/Período: {shift}/{period}'))
            p.textln('-----------------')

            p.set(align='left', font='b')
            p.textln('Ingresos (Efectivo):')
            p.textln(f'Bs. {amount_cash}')
            p.textln(f'Operaciones: {count_cash}')

            p.textln('-----------------')
            p.textln(transform_tildes_if_needed('Ingresos (Débito/Crédito):'))
            p.textln(f'Bs. {amount_debit_credit}')
            p.textln(f'Operaciones: {count_debit_credit}')

            p.textln('-----------------')
            p.textln('Ingresos (Post Pagos):')
            p.textln(f'Bs. {amount_post_payment}')
            p.textln(f'Operaciones: {count_post_payment}')

            p.set(align='left', font='b')
            p.textln('-----------------')
            p.textln('Ingresos de cierre:')
            p.textln(f'Bs: {form_bs}')
            p.textln(f'USD: {form_usd}')
            p.textln(f'COP: {form_cop}')
            p.textln(transform_tildes_if_needed(f'Débito/Crédito: {form_debit}'))

            p.cut()
            p.close()

        return_code = response_codes.PRINTER_IDLE

    except Exception as ex:
        logger.info(f'Error in generate_and_print_close_period_receipt (SIMULATED): {ex}')
        return_code = response_codes.PRINTER_UNKNOWN_ERROR

    return return_code


# noinspection PyPep8Naming,PyMethodMayBeStatic
class SimulatedPosPrinter:
    def __int__(self):
        logger.info(f'===> init SimulatedPosPrinter(....)')

    # noinspection SpellCheckingInspection
    def textln(self, t):
        logger.info(f'====> {t} <ln>')

    def text(self, t):
        logger.info(f'====> {t}')

    def hw(self, cmd):
        logger.info(f'==> CMD: {cmd}')

    def set(self, **kwargs):
        logger.info(f'==> SET: {kwargs}')

    def image(self, img):
        logger.info(f'==> IMG: {img}')

    def ln(self):
        logger.info(f'==> LN')

    def qr(self, *_, **__):
        logger.info(f'==> QR .....')

    def cut(self):
        logger.info(f'==> CUT .....')

    def close(self):
        logger.info(f'==> CLOSE <===')
