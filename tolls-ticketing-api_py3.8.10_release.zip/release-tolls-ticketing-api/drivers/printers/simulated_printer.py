from typing import Optional

from dispatcher_module.events.consts import PRINT_JOB_TYPE_SALE, PRINT_JOB_TYPE_CLOSE_PERIOD
import response_codes
from .base_printer import BasePrinter
from .simulated_printer_operations import generate_and_print_sale_receipt, generate_and_print_close_period_receipt

from logger import get_logger
logger = get_logger()


class SimulatedPrinter(BasePrinter):
    status = response_codes.PRINTER_IDLE
    worker_thread = None

    def check_status(self) -> str:
        return self.status

    def print_data(self, job_type: str, data: Optional[dict]):
        if data:
            self.status = response_codes.PRINTER_BUSY
            yield self.status

            if job_type == PRINT_JOB_TYPE_SALE:
                self.status = generate_and_print_sale_receipt('id_vendor', 'id_product', 'out_ep', data)

            elif job_type == PRINT_JOB_TYPE_CLOSE_PERIOD:
                self.status = generate_and_print_close_period_receipt('id_vendor', 'id_product', 'out_ep', data)
            else:
                self.status = response_codes.INVALID_REQUEST_PARAMETERS

            yield self.status

            if self.status != response_codes.PRINTER_IDLE:
                logger.error(f'Error in print_data: return_code="{self.status}"')
