import abc
from typing import Optional


class BasePrinter:
    @abc.abstractmethod
    def check_status(self) -> str:
        """
        Check the hardware printer and return a status_code as defined in response_codes.py, in the printer section.
        :return: The status code
        """
        pass

    @abc.abstractmethod
    def print_data(self, job_type: str, data: Optional[dict]):
        """
        Return a generator that will return the printer status every time until
        finished printing (either success or error)
        :param job_type: PRINT_JOB_TYPE_SALE or PRINT_JOB_TYPE_CLOSE_PERIOD
        :param data: The receipt data (vehicle category, vehicle weight, fare...)
        :return: yield return print statuses
        """
        pass
