import unidecode
from tolls_ticketing_proj import settings


def transform_tildes_if_needed(s: str) -> str:
    if settings.PRINTER_NO_ACCENTS:
        return unidecode.unidecode(s)
    else:
        return s
