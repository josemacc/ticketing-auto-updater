import logging
from . import consts


_config_loaded = False


def load_config():
    global _config_loaded
    if _config_loaded:
        return

    import logging.config
    import os

    # Logging facility
    log_directory = os.environ.get('LOG_DIRECTORY', '')
    app_log_file_name = os.path.join(log_directory, 'app.log')
    process_log_file_name = os.path.join(log_directory, 'process.log')

    logging_level = os.environ.get('LOGGING_LEVEL', 'ERROR')
    key = 'LOGGING_LEVEL_message_done'
    if not os.environ.get(key):
        logging.error(f'Using LOGGING_LEVEL={logging_level}')
        os.environ[key] = '1'

    # noinspection SpellCheckingInspection
    logger_config = {
        'version': 1,
        'disable_existing_loggers': True,
        'handlers': {
            consts.CONSOLE_HANDLER: {
                'level': logging_level,
                'class': 'logging.StreamHandler',
                'formatter': 'simple'
            },
            consts.APP_LOG_FILE_HANDLER: {
                'level': logging_level,
                'class': 'logging.handlers.RotatingFileHandler',
                'filename': app_log_file_name,
                'maxBytes': 1024 * 1024 * 5,  # 5MB
                'backupCount': 0,
                'formatter': 'simple',
                'encoding': 'UTF-8',
            },
            consts.PROCESS_LOG_FILE_HANDLER: {
                'level': logging_level,
                'class': 'logging.handlers.RotatingFileHandler',
                'filename': process_log_file_name,
                'maxBytes': 1024 * 1024 * 5,  # 5MB
                'backupCount': 0,
                'formatter': 'simple',
                'encoding': 'UTF-8',
            },
        },
        'formatters': {
            'verbose': {
                'format': '%(levelname)s|%(asctime)s|%(funcName)s --> %(message)s',
                'datefmt': "%d/%b/%Y %H:%M:%S"
            },
            'simple': {
                'format': '%(levelname)s|%(asctime)s --> %(message)s',
                'datefmt': "%d/%b/%Y %H:%M:%S"
            },
        },
        'loggers': {
            consts.APP_LOGGER: {
                'handlers': [consts.CONSOLE_HANDLER, consts.APP_LOG_FILE_HANDLER],
                'level': logging_level,
                'propagate': False,
            },
            consts.PROCESS_LOGGER: {
                'handlers': [consts.CONSOLE_HANDLER, consts.PROCESS_LOG_FILE_HANDLER],
                'level': logging_level,
                'propagate': False,
            },
        }
    }

    logging.config.dictConfig(logger_config)
    _config_loaded = True


def get_logger(logger=consts.APP_LOGGER):
    if not _config_loaded:
        load_config()

    return logging.getLogger(logger)
