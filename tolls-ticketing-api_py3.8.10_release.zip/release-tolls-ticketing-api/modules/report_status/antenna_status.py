from api.runtime_endpoints.operations import get_gate_mode
from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait
from api.models import consts as models_consts
import threading
import response_codes
from runtime_cache import runtime_data_cache
from runtime_cache import consts as runtime_const
from modules.base_module import BaseModule
from logger import get_logger
from tolls_ticketing_proj import settings

logger = get_logger()


class GetAntennaStatus(BaseModule):
    is_config_valid = False
    _db_path = None
    _stop_signal = None
    _thread = None

    def on_module_start(self):
        """
        Initialize the module by checking the database, the thread worker, etc.
        :return: bool. True if the whole initialization was successful, False otherwise
        """
        if self._thread:
            # module is already running
            return self.is_config_valid

        self.is_config_valid = self._create_processing_thread()
        return self.is_config_valid

    def on_module_stop(self):
        """
        Set the stop signal for the thread worker and wait for the thread to join. This gets called when the
        dispatch module is being stopped.
        :return: bool. True
        """
        if self._thread:
            self._stop_signal.set()
            self._thread.join()

            self._stop_signal = None
            self._thread = None
            return True

        else:
            # module was not running
            return False

    def _create_processing_thread(self):
        self._stop_signal = threading.Event()
        self._thread = threading.Thread(target=self._thread_worker, name='Antenna status worker', daemon=False)
        self._thread.start()
        return True

    def is_thread_running(self):
        return self._thread and self._thread.is_alive() and not self._stop_signal.is_set()

    def _thread_worker(self):
        """
        The thread worker that checks the inter-thread queue at regular intervals for messages to post to the database.
        """
        logger.debug('Antenna status thread worker started')
        self._stop_signal.wait(1)

        while self.is_thread_running():
            try:
                current_gate_mode = get_gate_mode()
                self.antenna_status()
            except Exception as ex:
                logger.error(f'Error in antenna_status worker: {ex}')
                break

            self._stop_signal.wait(1)
            if self._stop_signal.is_set():
                break

        logger.debug('Antenna status thread worker finished')

    @staticmethod
    def antenna_status():
        if settings.DISABLE_CONNECTION_DEVICE:
            pass

        else:
            success, result = api_call_and_wait('gate_device/antenna_messages', None)

            if not success:
                logger.error('Error getting antenna status from raspberry: success=False')

            elif type(result) != dict:
                logger.error('Error getting antenna status from raspberry: The result is not a dict')

            else:
                runtime_data_cache.set_variable(runtime_const.SYSTEM_NOTIFICATIONS, result)

