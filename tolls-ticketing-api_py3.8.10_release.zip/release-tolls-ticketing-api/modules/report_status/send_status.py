from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait
import threading

from modules.base_module import BaseModule

from logger import get_logger
from tolls_ticketing_proj import settings

logger = get_logger()


class SendStatus(BaseModule):
    is_config_valid = False
    _db_path = None
    _stop_signal = None
    _thread = None

    def on_module_start(self):
        """
        Initialize the module by checking the database, the thread worker, etc.
        :return: bool. True if the whole initialization was successful, False otherwise
        """
        if self._thread:
            # module is already running
            return self.is_config_valid

        self.is_config_valid = self._create_processing_thread()
        return self.is_config_valid

    def on_module_stop(self):
        """
        Set the stop signal for the thread worker and wait for the thread to join. This gets called when the
        dispatch module is being stopped.
        :return: bool. True
        """
        if self._thread:
            self._stop_signal.set()
            self._thread.join()

            self._stop_signal = None
            self._thread = None
            return True

        else:
            # module was not running
            return False

    def _create_processing_thread(self):
        self._stop_signal = threading.Event()

        self._thread = threading.Thread(target=self._thread_worker, daemon=False)
        self._thread.start()

        return True

    def is_thread_running(self):
        return bool(self._thread and self._thread.is_alive()) and not self._stop_signal.is_set()

    def _thread_worker(self):
        """
        The thread worker that checks the inter-thread queue at regular intervals for messages to post to the database.
        """
        logger.debug('Send status thread worker started')
        self._stop_signal.wait(10)

        while self.is_thread_running():
            try:
                self.report_status()
            except Exception as ex:
                logger.error(f'Error in send_status worker: {ex}')
                break
            self._stop_signal.wait(300)

        logger.debug('Send status thread worker finished')

    @staticmethod
    def report_status():
        status = {
            'node_code': settings.NODE_CODE,
            'node_type': settings.NODE_TYPE,
        }
        success, result = api_call_and_wait('regional_deferred/ping', status)

        if not success:
            logger.error(f"Error sending PING to regional. Success=False")
        elif type(result) != dict:
            logger.error(f"Error sending PING to regional. Success=True but result is not dict")
        else:
            logger.info(f"Sent PING to regional")
