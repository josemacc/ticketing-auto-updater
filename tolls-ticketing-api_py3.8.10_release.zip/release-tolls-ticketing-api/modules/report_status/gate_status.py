from typing import Optional
import threading

import response_codes
from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait
from api.models import consts as models_consts
from dispatcher_module.events import fsm_events, system_events
from api.runtime_endpoints.operations import get_gate_mode
from runtime_cache import runtime_data_cache, consts as runtime_consts

from modules import post_event
from modules.base_module import BaseModule

from logger import get_logger
from tolls_ticketing_proj import settings

logger = get_logger()

WORKER_STATE__WAITING_TO_OPEN = 'WORKER_STATE__WAITING_TO_OPEN'
WORKER_STATE__WAITING_TO_CLOSE = 'WORKER_STATE__WAITING_TO_CLOSE'


class GetGateStatus(BaseModule):
    is_config_valid = False
    _db_path = None
    _stop_signal: Optional[threading.Event] = None
    _thread = None

    def on_module_start(self):
        """
        Initialize the module by checking the database, the thread worker, etc.
        :return: bool. True if the whole initialization was successful, False otherwise
        """
        if self._thread:
            # module is already running
            return self.is_config_valid

        self.is_config_valid = self._create_processing_thread()
        return self.is_config_valid

    def on_module_stop(self):
        """
        Set the stop signal for the thread worker and wait for the thread to join. This gets called when the
        dispatch module is being stopped.
        :return: bool. True
        """
        if self._thread:
            self._stop_signal.set()
            self._thread.join()

            self._stop_signal = None
            self._thread = None
            return True

        else:
            # module was not running
            return False

    def _create_processing_thread(self):
        self._stop_signal = threading.Event()
        self._thread = threading.Thread(target=self._thread_worker, name='Gate status worker', daemon=False)
        self._thread.start()

        return True

    def is_thread_running(self):
        return self._thread and self._thread.is_alive() and not self._stop_signal.is_set()

    def _thread_worker(self):
        """
        The thread worker that checks the inter-thread queue at regular intervals for messages to post to the database.
        """
        logger.info('GetGateStatus thread worker started')
        state = WORKER_STATE__WAITING_TO_OPEN

        while self.is_thread_running():
            self._stop_signal.wait(2)
            if self._stop_signal.is_set():
                break

            try:
                # Vehicle Counters
                counters = GetGateStatus.get_gate_counters()
                self.post_event(
                    system_events.SystemStateEvent(self, {
                        'module': 'counters',
                        'data': counters
                    }))

                # Antenna State
                antenna_state = GetGateStatus.get_antenna_state()
                self.post_event(
                    system_events.SystemStateEvent(self, {
                        'module': 'antenna',
                        'data': antenna_state
                    })
                )

                # Gate status
                current_gate_mode = get_gate_mode()
                if current_gate_mode == models_consts.MANUAL_MODE:
                    continue

                if state == WORKER_STATE__WAITING_TO_OPEN:
                    is_gate_open = GetGateStatus.is_gate_status_open()
                    if is_gate_open:
                        state = WORKER_STATE__WAITING_TO_CLOSE

                elif state == WORKER_STATE__WAITING_TO_CLOSE:
                    is_gate_closed = GetGateStatus.is_gate_status_close()
                    if is_gate_closed:
                        state = WORKER_STATE__WAITING_TO_OPEN

                        if current_gate_mode == models_consts.AUTO_MODE:
                            # Gate opened and then, closed
                            post_event(fsm_events.StateMachineEvent(data={
                                'trigger': 'ev_gate_closed'
                            }))

            except Exception as ex:
                logger.error(f'Error in GetGateStatus worker: {ex}')

        logger.info('GetGateStatus thread worker finished')

    @staticmethod
    def check_gate_status() -> Optional[str]:
        if settings.DISABLE_CONNECTION_DEVICE:
            return None

        else:
            success, result = api_call_and_wait('gate_device/status', None)

            if not success or type(result) != dict:
                logger.error(f'Error in check_gate_status calling gate_device/status')
                return None

            return result.get('state')

    @staticmethod
    def get_gate_counters() -> list:
        if settings.DISABLE_CONNECTION_DEVICE:
            result = []

        else:
            success, result = api_call_and_wait('gate_device/counters', None)

            if not success or type(result) != dict:
                logger.error(f'Error in get_gate_counters calling gate_device/counters')
                result = []

            elif result.get('return_code') != response_codes.SUCCESS:
                logger.error(f'Error in get_gate_counters. The return_code is not SUCCESS')
                result = []

            else:
                result = result.get('counters')
                if type(result) != list:
                    logger.error(f'Error in get_gate_counters. The counters is not a list')
                    result = []

        result.append({
            'name': 'TVM',
            'vehicle_count': runtime_data_cache.get_variable(runtime_consts.TRANSIT_COUNTER)
        })

        return result

    @staticmethod
    def get_antenna_state():
        if settings.DISABLE_CONNECTION_DEVICE:
            return False

        return_code = response_codes.UNEXPECTED_ERROR
        antenna_state = False

        try:
            success, result = api_call_and_wait('gate_device/antenna_state', None)
            if success:
                if type(result) == dict:
                    return_code = result.get('return_code')
                    if not return_code:
                        return_code = response_codes.UNEXPECTED_ERROR
                        logger.warning('Warning in get_antenna_state: No return_code returned from the device')

            if return_code == response_codes.SUCCESS:
                antenna_state = result.get('antenna_state')

        except Exception as ex:
            logger.error(f'Error in get_counter_value: {ex}')

        return antenna_state

    @staticmethod
    def is_gate_status_close() -> Optional[bool]:
        result = GetGateStatus.check_gate_status()

        if type(result) == str:
            return result == 'st_gate_arm_down'
        else:
            return None

    @staticmethod
    def is_gate_status_open() -> Optional[bool]:
        result = GetGateStatus.check_gate_status()

        if type(result) == str:
            return result == 'st_gate_arm_up'
        else:
            return None
