from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait

from logger import get_logger
logger = get_logger()


def retrieve_build_version():
    """
    Retrieve the build version of the regional server.
    :return: str. The value returned from the api call to Regional
    """
    success, result = api_call_and_wait('regional/build_version', None)

    if success:
        build_version = result
        if not build_version:
            logger.warning(f'Error in retrieve_build_version. Empty response')
            build_version = '<not set>'
    else:
        build_version = '<error>'

    return build_version
