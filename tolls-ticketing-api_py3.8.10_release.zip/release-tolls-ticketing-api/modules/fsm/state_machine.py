from multipledispatch import dispatch

import response_codes
from common_consts import PRINTING_OPERATION_RETRY, PRINTING_OPERATION_CANCEL
from dispatcher_module.events import fsm_events, system_events, printer_events
from dispatcher_module.events.consts import PRINT_JOB_TYPE_SALE, PRINT_JOB_TYPE_CLOSE_PERIOD

from modules.base_module import BaseModule
from . import consts as fsm_consts

from runtime_cache import consts as runtime_consts
from runtime_cache import runtime_data_cache

from .base_state_machine import StateMachine
from . import operations

from logger import get_logger
logger = get_logger()


class AVMStateMachine(BaseModule):
    state_machine = None
    last_payment_data = None
    last_print_status = None
    last_print_job_type = None
    last_close_period_data = None
    state_data = None

    def __init__(self, name, uid, config):
        super().__init__(name, uid)
        self.error_time_out = 5
        self.current_operation = {}
        self.last_analyzed_card = None
        self.state_machine_running = False

        self.message_view_data = None
        self.message_view_state = None

        ssm_definition = config.get('ssm_definition')
        if type(ssm_definition) == dict:
            self.state_machine = StateMachine(self, ssm_definition)
            if self.state_machine.created:
                self.state_machine_running = True
                self.start()
            else:
                errors = {
                    fsm_consts.STATE_ERRORS: self.state_machine.state_errors,
                    fsm_consts.TRANSITION_ERRORS: self.state_machine.transition_errors
                }
                self.post_event(fsm_events.StateMachineErrorEvent(self.module_name, errors))

        else:
            errors = {
                fsm_consts.STATE_ERRORS: ['not defined'],
                fsm_consts.TRANSITION_ERRORS: ['not defined'],
            }
            self.post_event(fsm_events.StateMachineErrorEvent(self.module_name, errors))

        if not self.state_machine_running:
            self.state = None

        self.update_regional_build_version()

    regional_build_version_thread = None

    def update_regional_build_version(self):
        import threading

        def local_worker():
            result = operations.retrieve_build_version()
            runtime_data_cache.set_variable(runtime_consts.REGIONAL_BUILD_VERSION, result)
            logger.info(f'Startup regional build version={result}')
            self.regional_build_version_thread = None

        self.regional_build_version_thread = threading.Thread(target=local_worker, daemon=True)
        self.regional_build_version_thread.start()

    report_state_thread = None
    report_state_signal = None

    def report_state_worker(self):
        while self.is_worker_running():
            self.report_state_signal.wait(0.5)
            if self.message_view_data is not None and self.message_view_state != self.state:
                self.message_view_data = None

            self.post_event(
                system_events.SystemStateEvent(self, {
                    'module': 'app_fsm',
                    'data': {
                        'state': self.state,
                        'data': self.state_data,
                        'messageData': self.message_view_data,
                    }
                }))

    def is_worker_running(self):
        return bool(self.report_state_thread and self.report_state_thread.is_alive()) and \
               not self.report_state_signal.is_set()

    initial_states_thread = None

    def on_module_start(self):
        import threading
        self.report_state_signal = threading.Event()
        self.report_state_thread = threading.Thread(target=self.report_state_worker, daemon=False)
        self.report_state_thread.start()

        def local_worker():
            import time
            time.sleep(1)
            self.state_machine.dispatch(fsm_consts.EV_INIT)
            time.sleep(1)
            self.state_machine.dispatch(fsm_consts.EV_ENTER_OPERATIVE)

        self.initial_states_thread = threading.Thread(target=local_worker, daemon=True)
        self.initial_states_thread.start()

        return True

    def on_module_stop(self):
        self.report_state_signal.set()
        self.report_state_thread.join()

        self.report_state_signal = None
        self.report_state_thread = None
        return True

    def set_message_view_data(self, message: str, message_type: str):
        """
        Set the message that displayed on the /processing and /error pages on the UI.
        The message goes back to None automatically when the state machine goes to another state,
        it means that you don't need to reset it manually.

        :param message: The message string to display on the UI
        :param message_type: Any of info, warning, error. This value defines the style of the message on the UI
        """
        self.message_view_data = {
            'message': message,
            'type': message_type
        }

        # noinspection PyUnresolvedReferences
        self.message_view_state = self.state

    # Events
    @dispatch(fsm_events.StateMachineEvent)
    def do_dispatch_event(self, app_event):
        if not self.state_machine_running:
            logger.warning(f'Cannot process StateMachineEvent because the FSM is not running')
            return

        event_data = app_event.data
        trigger = event_data.get(fsm_consts.TRIGGER)
        if trigger in self.state_machine.events.keys():
            payload = event_data.get(fsm_consts.PAYLOAD, {})
            # noinspection PyTypeChecker
            self.state_machine.dispatch(trigger, payload)

    @dispatch(fsm_events.StateMachinePaymentProcessed)
    def do_dispatch_event(self, app_event):
        if not self.state_machine_running:
            logger.warning(f'Cannot process StateMachinePaymentProcessed because the FSM is not running')
            return

        payment_data = app_event.payment_data
        if payment_data:
            self.last_payment_data = payment_data

            self.state_machine.dispatch(fsm_consts.EV_PAYMENT_PROCESSED)
            # self.post_event(printer_events.PrintJob(PRINT_JOB_TYPE_SALE, self.last_payment_data))

    @dispatch(fsm_events.StateMachineEventPrintConfirmation)
    def do_dispatch_event(self, app_event):
        if not self.state_machine_running:
            logger.warning(f'Cannot process StateMachineEventPrintConfirmation because the FSM is not running')
            return

        print_request = app_event.print_request
        if print_request:
            self.state_machine.dispatch(fsm_consts.EV_PRINT_RECEIPT)
        else:
            self.state_machine.dispatch(fsm_consts.EV_CANCEL_PRINT_RECEIPT)

    @dispatch(printer_events.StateMachinePrinterIsDone)
    def do_dispatch_event(self, app_event: printer_events.StateMachinePrinterIsDone):
        if not self.state_machine_running:
            logger.warning(f'Cannot process StateMachinePrinterIsDone because the FSM is not running')
            return

        self.last_print_status = app_event.status
        self.last_print_job_type = app_event.job_type

        if app_event.job_type == PRINT_JOB_TYPE_SALE:
            self.state_machine.dispatch(
                fsm_consts.EV_PRINTER_SUCCESS_FOR_RECEIPT if app_event.status == response_codes.PRINTER_IDLE
                else fsm_consts.EV_PRINTER_ERROR_FOR_RECEIPT
            )

        if app_event.job_type == PRINT_JOB_TYPE_CLOSE_PERIOD:
            self.state_machine.dispatch(
                fsm_consts.EV_PRINTER_SUCCESS_FOR_CLOSE_PERIOD if app_event.status == response_codes.PRINTER_IDLE
                else fsm_consts.EV_PRINTER_ERROR_FOR_CLOSE_PERIOD
            )

    def on_print_receipt_enter(self):
        self.post_event(printer_events.PrintJob(PRINT_JOB_TYPE_SALE, self.last_payment_data))

    @dispatch(printer_events.StateMachinePrinterRetryOrCancel)
    def do_dispatch_event(self, app_event: printer_events.StateMachinePrinterRetryOrCancel):
        if not self.state_machine_running:
            logger.warning(f'Cannot process StateMachinePrinterRetryOrCancel because the FSM is not running')
            return

        if app_event.operation == PRINTING_OPERATION_RETRY:
            self.state_machine.dispatch(fsm_consts.EV_PRINTER_ERROR_RETRY)

        elif app_event.operation == PRINTING_OPERATION_CANCEL:
            self.state_machine.dispatch(fsm_consts.EV_PRINTER_ERROR_CANCEL)

    def on_print_close_period(self):
        self.post_event(printer_events.PrintJob(PRINT_JOB_TYPE_CLOSE_PERIOD, self.last_close_period_data))

        # payment_data = app_event.payment_data
        # if payment_data:
        #     self.last_payment_data = payment_data
        #     self.state_machine.dispatch(fsm_consts.EV_PAYMENT_PROCESSED)
        pass

    @dispatch(fsm_events.StateMachineCloseOperatorPeriod)
    def do_dispatch_event(self, app_event: fsm_events.StateMachineCloseOperatorPeriod):
        if not self.state_machine_running:
            logger.warning(f'Cannot process StateMachineCloseOperatorPeriod because the FSM is not running')
            return

        self.last_close_period_data = app_event.close_period_data
        self.state_machine.dispatch(fsm_consts.EV_CLOSE_PERIOD)

    @dispatch(fsm_events.StateMachineOperatorLogin)
    def do_dispatch_event(self, app_event: fsm_events.StateMachineOperatorLogin):
        if not self.state_machine_running:
            logger.warning(f'Cannot process StateMachineOperatorLogin because the FSM is not running')
            return

        if self.state != fsm_consts.ST_VEHICLE_TYPE_SELECTION:
            self.state_machine.dispatch(fsm_consts.EV_OPERATOR_LOGIN)
