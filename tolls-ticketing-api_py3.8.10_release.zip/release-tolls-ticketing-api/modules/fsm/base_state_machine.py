from transitions import Machine
from transitions.extensions.states import add_state_features, Tags, Timeout

from . import consts


from logger import get_logger
logger = get_logger()


@add_state_features(Tags, Timeout)
class StateMachine(Machine):

    @staticmethod
    def is_prop_or_callable(model, prop_or_method_name):
        if callable(model.__getattribute__(prop_or_method_name)):
            return True
        try:
            return type(model.__class__.__getattribute__(model.__class__, prop_or_method_name)) == property
        except AttributeError:
            return False

    def __init__(self, model, config):
        self.state_errors = []
        self.transition_errors = []

        # TODO: Build the list based on a decorator "st_callable"
        class_methods = [method_name for method_name in model.__dir__() if not method_name.startswith('__')
                         and self.is_prop_or_callable(model, method_name)]

        if type(config) == dict and {'states', 'transitions'}.issubset(config.keys()):
            states = config.get('states')
            state_names = [consts.ANY_STATE]
            parsed_states = states.copy()

            idx = -1
            for state in states:
                idx = idx + 1
                state_name = state.get(consts.STATE_NAME_KEY, 'unidentified')
                state_names.append(state_name)

                if not set(consts.MANDATORY_STATE_KEYS).issubset(state.keys()):
                    for key in consts.MANDATORY_STATE_KEYS:
                        self.state_errors.append({
                            'state': state_name,
                            'error': f'A mandatory key "{key}" is not included in state definition'
                        })

                for key in state.keys():
                    if key not in consts.STATE_VALID_KEYS:
                        self.state_errors.append({
                            'state': state_name,
                            'error': f'An invalid key "{key}" is included in state definition'
                        })

                for callback_key in consts.STATE_CALL_BACKS_KEYS:
                    if callback_key in state.keys():
                        callback_method = state.get(callback_key)
                        callback_method = None if callback_method == '' or callback_method == [] else callback_method
                        parsed_states[idx].pop(callback_key) if callback_method is None else parsed_states
                        callback_method = [callback_method] if isinstance(callback_method, str) else callback_method
                        if callback_method:
                            if not set(callback_method).issubset(set(class_methods)):
                                self.state_errors.append({
                                    'state': state_name,
                                    'error': f'The callback "{callback_method}" is not defined on key "{callback_key}"'
                                })

            transitions = config.get(consts.FSM_TRANSITIONS_KEY)
            events = config.get(consts.FSM_EVENTS_KEY)

            idx = -1
            parsed_transitions = transitions.copy()
            for transition in transitions:
                idx = idx + 1
                source = transition.get(consts.TRANSITION_SOURCE_KEY, 'un_known')
                source = consts.ANY_STATE if source == consts.ANY_STATE_KEY else \
                    None if source == 'None' else source
                parsed_transitions[idx].update({consts.TRANSITION_SOURCE_KEY: source})

                dest = transition.get('dest', 'un_known')
                dest = consts.ANY_STATE if dest == consts.ANY_STATE_KEY else \
                    None if dest == 'None' else dest
                parsed_transitions[idx].update({consts.TRANSITION_DEST_KEY: dest})

                transition_name = '{}_to_{}'.format(source, dest)

                if not set(consts.MANDATORY_TRANSITION_KEYS).issubset(transition.keys()):
                    for key in consts.MANDATORY_TRANSITION_KEYS:
                        self.state_errors.append({
                            'transition': transition_name,
                            'error': f'A mandatory key "{key}" is not included in state definition'
                        })

                if source and source not in state_names:
                    self.state_errors.append({
                        'transition': transition_name,
                        'error': f'The source "{source}" is not included in the states definition'
                    })

                if dest and dest not in state_names:
                    self.state_errors.append({
                        'transition': transition_name,
                        'error': f'The destination "{dest}" is not included in the states definition'
                    })

                for key in transition.keys():
                    if key not in consts.TRANSITION_VALID_KEYS:
                        self.state_errors.append({
                            'transition': transition_name,
                            'error': f'An invalid key "{key}" is included in the transition definition'
                        })

                if transition[consts.TRANSITION_TRIGGER_KEY] not in events:
                    trigger_name = transition.get(consts.TRANSITION_TRIGGER_KEY)
                    self.state_errors.append({
                        'transition': transition_name,
                        'error': f'The trigger "{trigger_name}" is not included in events definition'
                    })

                for callback_key in consts.TRANSITION_CALL_BACKS_KEYS:
                    if callback_key in transition.keys():
                        callback_method = transition.get(callback_key, None)
                        callback_method = None if callback_method == '' or callback_method == [] else callback_method
                        parsed_transitions[idx].pop(callback_key) if callback_method is None else parsed_states
                        callback_method = [callback_method] if isinstance(callback_method, str) else callback_method
                        if callback_method:
                            if not set(callback_method).issubset(set(class_methods)):
                                self.state_errors.append({
                                    'transition': transition_name,
                                    'error': f'The callback "{callback_method}" is not defined on key "{callback_key}"'
                                })

            if not (self.state_errors or self.transition_errors):
                initial_state = config['initial']
                self.state_machine = super().__init__(model=model, states=parsed_states, transitions=parsed_transitions,
                                                      initial=initial_state, ignore_invalid_triggers=True)
                self.created = True
            else:
                self.created = False
        else:
            logger.error('Error creating FSM machine: config is not a dict or does not have '
                         'the expected keys "states" and "transitions"')

        if type(config) == dict and 'events' in config.keys():
            config.pop('events')

        if self.state_errors:
            logger.error(f'Please, fix the following state errors '
                         f'before using the state machine: {self.state_errors}')

        if self.transition_errors:
            logger.error(f'Please, fix the following transition errors '
                         f'before using the state machine: "{self.transition_errors}"')
