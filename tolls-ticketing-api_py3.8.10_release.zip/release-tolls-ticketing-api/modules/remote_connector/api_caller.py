import os
import pickle
import random
import time
import requests
from multipledispatch import dispatch
import threading
import weakref

import utils
import tolls_ticketing_proj.settings as settings
from common_consts import VALUES_FOR_TRUE
from dispatcher_module.events.api_caller_events import ApiCallerEvent
from modules.base_module import BaseModule

from logger import get_logger
logger = get_logger()

RETURN_TYPE_STR = 'str'
RETURN_TYPE_JSON = 'json'
RETURN_TYPE_BINARY = 'binary'

DEFAULT_RETURN_TYPE = RETURN_TYPE_STR
VALID_RETURN_TYPES = (RETURN_TYPE_STR, RETURN_TYPE_JSON, RETURN_TYPE_BINARY)

DEFAULT_TIMEOUT = 8.0


class ApiCaller(BaseModule):
    api = None
    session_path = None
    is_config_valid = False
    sessions = {}
    sessions_lock = None
    sessions_logging_in_locks = {}
    registered_login_handlers = {}

    def init_module(self):
        super(ApiCaller, self).init_module()
        self.is_config_valid = True
        self.api = {}
        servers = self.config.get('servers', {})

        # Load and validate session path
        self.session_path = os.path.join(settings.SESSIONS_PATH, self.config.get('session_path', ''))
        if not utils.dir_is_writable(self.session_path):
            logger.error(f'Invalid "session_path". Directory "{self.session_path}" is not writable')
            self.is_config_valid = False
            return

        # Clear corrupted sessions. This can happen if the service is interrupted without a proper shutdown
        # Such as in the event of a power failure or when killing the service via KILL signal
        self.clear_zero_session_files()

        # Load default values
        default_use_session = self.config.get('default_use_session', False) in VALUES_FOR_TRUE
        default_return_type = self.config.get('default_return_type', 'text')
        default_method = self.config.get('default_method', 'GET')
        default_login_fn = self.config.get('default_login_fn')

        try:
            default_timeout = float(self.config.get('default_timeout', DEFAULT_TIMEOUT))
        except ValueError:
            logger.warning(f'Invalid default_timeout value. Using default {DEFAULT_TIMEOUT} secs')
            default_timeout = DEFAULT_TIMEOUT

        # Process the server items
        for server_name, server_data in servers.items():
            apis = server_data.get('apis', {})

            server_base_url = server_data.get('base_url')
            if not server_base_url:
                # noinspection HttpUrlsUsage
                server_base_url = 'http://'
            else:
                if server_base_url.endswith('/'):
                    server_base_url = server_base_url[:-1]

            login_fn = server_data.get('login_fn', default_login_fn)
            login_username = server_data.get('login_username')
            login_password = server_data.get('login_password')

            server_use_session = server_data.get('use_session', default_use_session)
            server_return_type = server_data.get('return_type', default_return_type)
            server_method = server_data.get('method', default_method)

            try:
                server_timeout = float(server_data.get('timeout', default_timeout))
            except ValueError:
                logger.warning(f'Invalid timeout value for "{server_name}". Using default {default_timeout} secs')
                server_timeout = default_timeout

            def generate_api_id(api_name_param):
                return f'{server_name}/{api_name_param}'

            # Get the entry acting as the authentication api
            authentication_api = None
            for api_name, api_data in apis.items():
                if api_data.get('is_authentication_api') in VALUES_FOR_TRUE:
                    authentication_api = api_name
                    break

            # Process the API items
            for api_name, api_data in apis.items():
                api_id = generate_api_id(api_name)
                api_url = server_base_url + api_data.get('url')
                use_session = api_data.get('use_session', server_use_session)
                session_key = api_data.get('session_key', server_name)
                return_type = api_data.get('return_type', server_return_type)
                method = api_data.get('method', server_method)

                try:
                    timeout = float(api_data.get('timeout', server_timeout))
                except ValueError:
                    logger.warning(f'Invalid timeout value for "{api_name}". Using default {server_timeout} secs')
                    timeout = server_timeout

                api_config = {
                    'url': api_url,
                    'use_session': use_session,
                    'session_key': session_key,
                    'return_type': return_type,
                    'method': method,
                    'timeout': timeout,
                }

                # Include the login info if this is not the api entry used to log-in
                if api_name != authentication_api:
                    api_config.update({
                        'login_info': {
                            'fn': login_fn,
                            'api': generate_api_id(authentication_api),
                            'username': login_username,
                            'password': login_password,
                        }
                    })
                self.api.update({api_id: api_config})

        # Session management
        if self.is_config_valid:
            self.sessions = {}
            self.sessions_lock = threading.Lock()
            for api_name, api_data in self.api.items():
                if api_data['use_session']:
                    session_key = api_data['session_key']
                    if session_key not in self.sessions_logging_in_locks.keys():
                        self.sessions_logging_in_locks[session_key] = threading.Lock()
                        self.load_session(session_key)

    def register_login_handler(self, login_fn_name, handler):
        if callable(handler):
            # noinspection PyTypeChecker
            self.registered_login_handlers[login_fn_name] = weakref.WeakMethod(handler)
        else:
            self.unregister_login_handler(login_fn_name)

    def unregister_login_handler(self, login_fn_name):
        if login_fn_name in self.registered_login_handlers.keys():
            del self.registered_login_handlers[login_fn_name]

    def on_module_start(self):
        return self.is_config_valid

    @dispatch(ApiCallerEvent)
    def do_dispatch_event(self, app_event):
        if not self.is_config_valid:
            return

        data = app_event.data
        api_name = data.get('api')
        return_queue = data.get('return_queue')
        return_event_class = data.get('return_event_class')

        if api_name and (api_name in self.api):
            params = data.get('params')
            api_config = self.api[api_name]

            url = api_config.get('url')
            method = api_config['method']
            timeout = api_config['timeout']
            use_session = api_config['use_session']
            session_key = api_config['session_key']
            return_type = api_config['return_type']

            login_info = api_config.get('login_info')

            url = utils.replace_params(url, params)
            if method == 'GET':
                params = None

            thread_name = f"api_worker_{api_name}[{method}]_{random.randrange(1000, 9999)}"
            worker_thread = threading.Thread(
                target=self.request_worker, name=thread_name,
                args=(api_name, url, params, method, timeout, use_session,
                      return_type, return_queue, return_event_class, session_key, login_info), daemon=True)
            worker_thread.start()
        else:
            logger.error(f'Api "{api_name}" does not exist... Check api caller config file')
            response = {
                'response': None,
                'success': False
            }
            return_queue.put(response)

    # noinspection PyUnusedLocal
    def request_worker(self, api_name, url, params, method, timeout, use_session,
                       return_type, return_queue, return_event_class, session_key, login_info):
        try:
            request_kwargs = {
                'json': params,
                'timeout': timeout
            }
            if params is None:
                del request_kwargs['json']

            if use_session:
                # Make the request using HTTP sessions
                with self.sessions_lock:
                    current_session = self.sessions.get(session_key)
                    if not current_session:
                        current_session = requests.Session()
                        self.sessions[session_key] = current_session
                        self.save_session(session_key)

                # Add the referer and ssl certificate if specified
                if settings.POST_REFERER:
                    current_session.headers.update({'referer': f'{settings.POST_REFERER}'})
                if url.lower().startswith('https://') and settings.SSL_CERT:
                    if settings.SSL_KEY:
                        current_session.cert = (settings.SSL_CERT, settings.SSL_KEY)
                    else:
                        current_session.verify = settings.SSL_CERT

                response = current_session.request(method, url, **request_kwargs)

                if response.status_code == 403 and login_info:
                    login_fn = login_info.get('fn')
                    login_handler = self.registered_login_handlers.get(login_fn)

                    if login_handler and callable(login_handler()):
                        with self.sessions_logging_in_locks[session_key]:
                            if login_handler()(login_info):
                                time.sleep(0.1)
                                response = current_session.request(method, url, **request_kwargs)
                            else:
                                logger.error(f'Unable to login for api "{api_name}"')

                with self.sessions_lock:
                    self.save_session(session_key)
            else:
                # Make the request without HTTP sessions
                response = requests.request(method, url, **request_kwargs)

        except Exception as e:
            response = None
            logger.error(f'Error calling url "{url}". The exception is: {e}')

        # Transform the response as required by the caller
        success = (response is not None) and (response.status_code == 200)
        if success:
            try:
                result = response.content
                if return_type == RETURN_TYPE_STR:
                    encoding = response.apparent_encoding
                    result = result.decode(encoding)
                elif return_type == RETURN_TYPE_JSON:
                    result = response.json()
                elif return_type == RETURN_TYPE_BINARY:
                    pass
            except Exception as parse_ex:
                logger.error(f'Error parsing the ApiCaller return data: {[parse_ex]}')
                result = None
                success = False

        else:
            result = None

        # Send the response to the caller
        data = {
            'success': success,
            'response': result,
        }
        if return_queue:
            return_queue.put(data)

        if return_event_class:
            self.post_event(return_event_class(self.module_uid, data))

    def session_filename(self, api_name):
        return os.path.join(self.session_path, api_name + '.pickle')

    def clear_zero_session_files(self):
        from os import listdir, unlink
        from os.path import isfile, join

        files_to_delete = []
        for f in listdir(self.session_path):
            file_path = join(self.session_path, f)
            file_size = os.path.getsize(file_path)
            if isfile(file_path) and file_size == 0:
                files_to_delete.append(file_path)

        removed_count = 0
        for fn in files_to_delete:
            try:
                unlink(fn)
                removed_count += 1
            except Exception as e:
                logger.error(f'=== Unable to remove corrupted session file: {e}')

        if removed_count:
            logger.info(f'=== Removed {removed_count} corrupted session file(s)')

    def load_session(self, session_key):
        try:
            with open(self.session_filename(session_key), 'rb') as f:
                self.sessions[session_key] = pickle.load(f)

            logger.debug(f'Restored the ApiCaller session for key "{session_key}"')

        except (IOError, ValueError):
            pass

    def save_session(self, session_key):
        try:
            with open(self.session_filename(session_key), 'wb') as f:
                pickle.dump(self.sessions[session_key], f)
            return True

        except (IOError, ValueError) as e:
            logger.error(f'IO error saving the ApiCaller session "{session_key}": {e}')

        return False

    @staticmethod
    def is_a_valid_return_type(value):
        if type(value) == str:
            value = value.lower()

        return value in VALID_RETURN_TYPES
