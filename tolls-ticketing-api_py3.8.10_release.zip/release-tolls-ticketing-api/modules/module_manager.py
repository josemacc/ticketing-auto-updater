import os
import importlib
import inspect
import threading
import time

import utils
from common_consts import VALUES_FOR_TRUE

from logger import get_logger
logger = get_logger()

MODULE_NAME = 'ModuleManager'


class ModuleManager:
    modules = {}

    def start(self):
        pass

    def stop(self):
        from .base_module import BaseModule

        def worker(module_obj: BaseModule):
            logger.debug(f"  * Stopping module '{module_obj}'...")
            module_obj.stop()

        # stop the modules in parallel
        threads_to_wait_for = []
        for _, module in self.modules.items():
            th = threading.Thread(name=f'waiter_of_{module.module_name}', target=worker, daemon=False, args=(module,))
            th.start()
            threads_to_wait_for.append(th)

        # wait for all the modules to be stopped
        start_time = time.time()

        while True:
            all_stopped = True

            # get a copy because I need to modify "threads_to_wait_for" inside the loop
            tmp_threads_to_check = list(threads_to_wait_for)
            current_time = time.time()
            waiting_for_too_long = current_time - start_time > 5

            for t in tmp_threads_to_check:
                if t.is_alive():
                    all_stopped = False
                    if waiting_for_too_long:
                        logger.info(f'  * Still waiting for module "{t.name}" to stop')
                    break
                else:
                    t.join()
                    threads_to_wait_for.remove(t)

            if waiting_for_too_long:
                # rolling timer, to prevent too much logging on stuck threads
                start_time = time.time()

            if all_stopped:
                break

            time.sleep(0.02)

    def load_modules(self, base_path, config_filepath, use_template_context=None, required_template_vars=None):
        """
        Load the dynamic modules from a "modules" directory.

        :param base_path: str. The root path where to look for modules
        :param config_filepath: str. The filepath of the configuration in JSON format
        :param use_template_context: None|dict. Interpret the JSON file as a template and evaluates {{expression}}
        :param required_template_vars: None|list|tuple. A list of variable names that must exist if they were
        referenced in the context. If a listed variable is used in the template, but it doesn't exist in the context,
        an exception is raised.
        :return: None
        """
        try:
            data = utils.load_json(config_filepath, use_template_context, required_template_vars)
        except Exception as e:
            f_name = os.path.split(config_filepath)[1]
            logger.error(f'Unable to load configuration file "{f_name}": {e}')
            return False

        if type(data) not in (list, tuple):
            return False

        for d in data:
            klass = d.get('class', '')
            config = d.get('config', {})
            mod_friendly_name = d.get('name')
            uid = d.get('uid')

            active = d.get('active', True)
            if active not in VALUES_FOR_TRUE:
                continue

            if not uid:
                logger.error(f'Error loading module name="{mod_friendly_name}" '
                             f'class="{klass}" because it does not have "uid"')
                return False

            this_module_str = (base_path + '.' + klass).replace('..', '_').replace('/', '_')
            this_module_path = '.'.join(this_module_str.split('.')[:-1])
            this_module_classname = this_module_str.split('.')[-1]

            try:
                mod = importlib.import_module(this_module_path)
                for member_name, obj in inspect.getmembers(mod):
                    if inspect.isclass(obj) and obj.__module__.startswith(
                            this_module_path) and member_name == this_module_classname:
                        module = obj(mod_friendly_name, uid, config=config)
                        self.register_new_module(module)
            except Exception as e:
                logger.error(f'Error loading module name="{mod_friendly_name}" class="{klass}": {e}')
                return False

        return True

    def register_new_module(self, module):
        if module.module_uid not in self.modules:
            self.modules.update({module.module_uid: module})

            # status_changed_event = ModuleStatusChanged(MODULE_NAME, event_consts.EV_MODULE_LOADED)
            # self.post_event(status_changed_event)
            if module.auto_run:
                if module.start():
                    logger.info(f'Module "{module.module_name}" started')
                else:
                    logger.warning(f'Module "{module.module_name}" did not start properly')

                # status_changed_event = ModuleStatusChanged(MODULE_NAME, event_consts.EV_MODULE_LOADED)
                # self.post_event(status_changed_event)
        else:
            logger.warning(f'Module "{module.module_name}" is already registered')

    def get_module(self, module_uid):
        return self.modules.get(module_uid, None)

    def remove_module(self, module):
        if module.module_name not in self.modules:
            self.modules.pop(module.module_name)
        else:
            logger.warning(f'Module "{module.module_name}" is not registered')

    def post_event(self, event):
        for module in self.modules:
            handled_events = self.modules[module].handled_events
            event_type = event.__class__.__name__
            if event_type in handled_events:
                module_ref = self.modules[module]
                module_ref.dispatch_event(event)
