import itertools
from queue import Queue
from multipledispatch import dispatch
from dispatcher_module.event_dispatcher.event_dispatcher_thread import EventDispatcherThread
from dispatcher_module.events.base_event import BaseEvent
from modules import consts as modules_consts, post_event

from logger import get_logger
logger = get_logger()


class BaseModule(object):
    def __init__(self, module_name, module_uid, auto_run=True, config=None):
        if config is None:
            config = {}

        self.module_name = module_name
        self.module_uid = module_uid
        self.module_status = modules_consts.MOD_ST_CREATED
        self.event_dispatcher = None
        self.config = config
        self.queued_events = Queue()
        self.queued_error_conditions = Queue()
        self.auto_run = auto_run

        # create_event_dispatcher
        if self.event_dispatcher is None:
            self.event_dispatcher = EventDispatcherThread(module=self, event_inbox_queue=self.queued_events)
        self.init_module()

    def init_module(self):
        if self.module_status == modules_consts.MOD_ST_CREATED:
            self.module_status = modules_consts.MOD_ST_INITIATED

    def start(self):
        if self.module_status == modules_consts.MOD_ST_RUNNING:
            return True

        if self.module_status == modules_consts.MOD_ST_INITIATED:
            self.event_dispatcher.start()

            self.module_status = modules_consts.MOD_ST_RUNNING if self.on_module_start() \
                else modules_consts.MOD_ST_INITIATED
            return self.module_status == modules_consts.MOD_ST_RUNNING

        return False

    def stop(self):
        self.event_dispatcher.stop()

        if self.is_running():
            self.on_module_stop()
            self.module_status = modules_consts.MOD_ST_STOPPED

        return True

    def is_running(self):
        return self.module_status == modules_consts.MOD_ST_RUNNING

    @property
    def handled_events(self):
        handled_events = []
        event_classes = []
        if 'do_dispatch_event' in self.__dir__():
            event_classes = list(self.do_dispatch_event.funcs.keys())
        event_classes = itertools.chain(*event_classes)
        for event_class in event_classes:
            handled_events.append(event_class.__name__)
        return handled_events

    @staticmethod
    def post_event(event):
        post_event(event)

    def dispatch_event(self, event):
        self.queued_events.put(event)

    def set_error_condition(self, error_condition):
        pass

    # noinspection PyMethodMayBeStatic
    def on_module_start(self):
        """Return True to signal that the module successfully started"""
        return True

    # noinspection PyMethodMayBeStatic
    def on_module_stop(self):
        """Return True to signal that the module successfully stopped"""
        return True

    @dispatch(BaseEvent)
    def do_dispatch_event(self, event):
        logger.debug(f'Received event "{event.name}", triggered by module "{self.module_name}"')
