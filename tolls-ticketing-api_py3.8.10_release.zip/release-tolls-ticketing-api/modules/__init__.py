from modules.module_manager import ModuleManager

_module_manager_singleton = None


def current_manager():
    global _module_manager_singleton

    if not _module_manager_singleton:
        _module_manager_singleton = ModuleManager()

    return _module_manager_singleton


def post_event(event):
    current_manager().post_event(event)
