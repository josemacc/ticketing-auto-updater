import threading
import uuid
import json
from typing import Optional

import response_codes
from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait
from modules.base_module import BaseModule
from api.models.secure_messages import SecureMessage
from . import messages_consts
import common_consts
from runtime_cache import consts as runtime_const
from runtime_cache import runtime_data_cache

from logger import get_logger
logger = get_logger()


DELAY_AFTER_SEND_SUCCESS = 0.2
DELAY_AFTER_SEND_FAILURE = 5
DELAY_IF_NO_MESSAGES = 1


class MessageQueue(BaseModule):
    is_config_valid = False
    _stop_signal = None
    _database_thread = None

    def on_module_start(self):
        if self._database_thread:
            # module is already running
            return self.is_config_valid

        self.is_config_valid = self._create_processing_thread()
        return self.is_config_valid

    def on_module_stop(self):
        if self._database_thread:
            self._stop_signal.set()
            self._database_thread.join()

            self._stop_signal = None
            self._database_thread = None
            return True

        else:
            # module was not running
            return False

    def _create_processing_thread(self):
        self._stop_signal = threading.Event()
        self._database_thread = threading.Thread(target=self._thread_worker, daemon=False)
        self._database_thread.start()
        return True

    def is_thread_running(self):
        return bool(self._database_thread and self._database_thread.is_alive()) and not self._stop_signal.is_set()

    @staticmethod
    def _extract_next_db_message() -> Optional[SecureMessage]:
        """
        Retrieves the next message to process from the queue. The criteria to pick the next message is
        the least recent timestamp.

        :return: The next message to process or None if there is the queue is empty or there was an error
        """
        try:
            result = SecureMessage.objects.all().order_by('-created_on').first()
        except Exception as ex:
            logger.error(f'Error in _extract_next_db_message: {ex}')
            result = None

        return result

    def _thread_worker(self):
        logger.debug('SecureMessages worker started')

        # do an initial delay
        self._stop_signal.wait(1)

        while self.is_thread_running():
            msg = self._extract_next_db_message()
            if msg:
                if self._process_message(msg):
                    self._stop_signal.wait(DELAY_AFTER_SEND_SUCCESS)
                else:
                    self._stop_signal.wait(DELAY_AFTER_SEND_FAILURE)
            else:
                self._stop_signal.wait(DELAY_IF_NO_MESSAGES)

        logger.debug('SecureMessages thread worker stopped')

    @staticmethod
    def _process_message(msg: SecureMessage) -> bool:
        """
        Process a message. This is, try to send it via the ApiCaller. If this function succeeds, the message will be
        removed from the database queue.

        :param msg: The message to process as returned by the method "_extract_next_db_message"
        :return: True if the message has been processed, False otherwise
        """
        success = False
        return_data = None
        api_name = None

        try:
            api_name = messages_consts.MESSAGE_TYPE_TO_API_NAME.get(msg.message_type)
            if not api_name:
                raise Exception(f'Invalid message type "{msg.message_type}"')

            message_payload = json.loads(msg.json_payload)
            prepared_data = {
                'message_id': str(msg.message_id),
                'node_id': msg.node_id,
                'parent_site_id': msg.parent_site_id,
                'company_id': msg.company_id,

                'employee_id': msg.employee_id,
                'work_shift': msg.work_shift,
                'work_period': msg.work_period,
                'created_on': msg.created_on.strftime('%Y-%m-%d %H:%M:%S'),
                'message_payload': message_payload,
            }
            success, return_data = api_call_and_wait(api_name, prepared_data)
            if not success:
                logger.debug(f'Deferred message call api_name="{api_name}" failed')

        except Exception as e:
            logger.error(f'Error in message_manager._process_message: {e}')

        if success:
            msg.delete()
            if type(return_data) == dict and ('return_code' in return_data):
                return_code = return_data.get('return_code')
                if return_code == response_codes.SUCCESS:
                    logger.info(f'Secure message succeeded for api_name="{api_name}"')
                else:
                    logger.warning(f'Secure message succeeded but returned an error: '
                                   f'api_name="{api_name}", return_code={return_code}')
            else:
                logger.info(f'Secure message succeeded for api_name="{api_name}"')

        return success


def generate_message_id():
    """Generate an unique packet id."""
    return str(uuid.uuid1())


def post_deferred_message(message_type: str, message_payload: Optional[dict]):
    """
    Queue a new message to be safely sent in the future. The processing thread will pick it up from the queue and
    insert it on the Sqlite3 table to make it persistent across restarts of the app.

    :param message_type: Any of the message types defined in the message_consts module
    :param message_payload: The data to be sent as part of the call
    """
    try:
        api_name = messages_consts.MESSAGE_TYPE_TO_API_NAME.get(message_type)
        if not api_name:
            raise Exception(f'Invalid message type "{message_type}"')

        message_id = generate_message_id()

        node_info = runtime_data_cache.get_variable(runtime_const.NODE_INFO)
        node_id = node_info.get('id') if type(node_info) == dict else None

        toll_site_info = runtime_data_cache.get_variable(runtime_const.TOLL_SITE_INFO)
        parent_site_id = toll_site_info.get('id') if type(toll_site_info) == dict else None

        company_info = runtime_data_cache.get_variable(runtime_const.COMPANY_INFO)
        company_id = company_info.get('id') if type(company_info) == dict else None

        employee_info = runtime_data_cache.get_variable(runtime_const.OPERATOR_INFO)
        employee_id = employee_info.get('id') if type(employee_info) == dict else None

        work_shift = runtime_data_cache.get_variable(common_consts.WORK_SHIFT_KEY)
        work_period = runtime_data_cache.get_variable(common_consts.WORK_PERIOD_KEY)

        json_payload = json.dumps(message_payload, default=str)

        msg = SecureMessage(message_type=message_type, message_id=message_id,
                            node_id=node_id, parent_site_id=parent_site_id,
                            company_id=company_id, employee_id=employee_id,
                            work_shift=work_shift, work_period=work_period,
                            json_payload=json_payload)
        msg.save()

        return True

    except Exception as ex:
        logger.error(f'Error in post_deferred_message: {ex}')
        return False
