MESSAGE_TYPE_REGISTER_PAYMENT = 'register_payment'
MESSAGE_TYPE_REGISTER_CLOSE_PERIOD = 'register_close_period'

MESSAGE_TYPE_TO_API_NAME = {
    MESSAGE_TYPE_REGISTER_PAYMENT: 'regional_deferred/register_payment',
    MESSAGE_TYPE_REGISTER_CLOSE_PERIOD: 'regional_deferred/register_close_period'
}
