import json
from multipledispatch import dispatch

from modules.base_module import BaseModule
from dispatcher_module.events.system_events import SystemStateEvent

from runtime_cache import runtime_data_cache
from runtime_cache import consts as runtime_const


class SystemState(BaseModule):
    system_state = {}

    @dispatch(SystemStateEvent)
    def do_dispatch_event(self, app_event):
        data = app_event.data
        reporting_module = data.get('module')
        reported_data = data.get('data')

        new_state = json.loads(json.dumps(self.system_state, default=str))
        new_state[reporting_module] = reported_data

        self.system_state = new_state
        runtime_data_cache.set_variable(runtime_const.SYSTEM_STATE, self.system_state)
