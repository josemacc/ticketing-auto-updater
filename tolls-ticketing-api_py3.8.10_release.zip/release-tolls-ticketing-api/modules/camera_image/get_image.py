import base64
import os
from datetime import datetime

import response_codes
import runtime_cache.runtime_data_cache
import tolls_ticketing_proj.settings as settings
import utils
from modules.base_module import BaseModule

from runtime_cache import consts as runtime_const
from multipledispatch import dispatch
from dispatcher_module.events import camera_event

from runtime_cache import runtime_data_cache
from runtime_cache.consts import LAST_IMAGE_PLATE

from logger import get_logger
logger = get_logger()

try:
    import cv2
except Exception as e:
    logger.error(f'Error in get_image importing opencv: {e}')


# noinspection PyUnresolvedReferences
class AlprCamera(BaseModule):
    is_config_valid = False
    camera_url = None
    template_camera_path = None
    return_code = None
    camera_connection = None

    def init_module(self):
        super(AlprCamera, self).init_module()
        self.is_config_valid = True
        if not settings.DISABLE_LICENCE_PLATE_CAMERA:
            # load and validate template path and camera url
            self.template_camera_path = os.path.join(
                settings.TEMPLATE_CAMERA_PATH, self.config.get('template_camera_path', ''))

            if not utils.dir_is_writable(self.template_camera_path):
                logger.error(f'Error in AlprCamera module: Directory "template_camera_path" '
                             f'("{self.template_camera_path}") is not writable')
                self.is_config_valid = False

            self.camera_url = settings.CAMERA_URL

    @dispatch(camera_event.GetLicensePlate)
    def do_dispatch_event(self, app_event: camera_event.GetLicensePlate):
        logger.info(f'++++ Event GetLicensePlate received')

        lane_info = runtime_data_cache.get_variable(runtime_const.LANE_INFO) or {}
        lane_code = lane_info.get('lane_code', '???')
        try:
            self.camera_connection = cv2.VideoCapture(self.camera_url)
            self.return_code = response_codes.CAMERA_SUCCESS
        except Exception as ex:
            raise Exception(f'Error in AlprCamera module, could not connect to the camera: {ex}')

        if not settings.DISABLE_LICENCE_PLATE_CAMERA:
            logger.info(f'++++ Event Camera is enabled in settings')
            if self.camera_connection.isOpened():
                logger.info(f'++++ Event Camera is open')
                try:
                    ret, frame = self.camera_connection.read()
                    if ret:
                        logger.info(f'++++ Event Camera read return True')
                        return_code = self.take_and_save_plate(lane_code, frame)
                        logger.info(f'++++ Event Camera take_and_save_plate return_code={return_code}')

                        if return_code == response_codes.CAMERA_SUCCESS:
                            self.delete_older_image_files()
                            self.camera_connection.release()
                    else:
                        logger.info(f'++++ Event Camera read return False')

                except Exception as ex:
                    logger.error(f'Error in AlprCamera module while reading/saving the camera image: {ex}')

            else:
                logger.info(f'++++ Event Camera is NOT open')
                self.post_event(camera_event.ImageCapturedFail(error_code=response_codes.CAMERA_NOT_CONNECTED))

        else:
            logger.info(f'++++ Event Camera is NOT enabled in settings')

    def delete_older_image_files(self):
        list_of_files = os.listdir(self.template_camera_path)
        full_paths = [os.path.join(self.template_camera_path, x) for x in list_of_files]
        full_paths.sort(key=os.path.getctime)

        # TODO: Make the amount of images to keep, a variable on the .env file
        amount_of_images_to_keep = 5

        while len(full_paths) > amount_of_images_to_keep:
            try:
                os.remove(full_paths[0])
            except Exception as ex:
                logger.error(f'Error in AlprCamera module while deleting the saved image file: {ex}')

            full_paths.pop(0)

    def take_and_save_plate(self, lane_code, frame):
        try:
            # generate the filename and save the frame
            date_component = datetime.now().strftime('%Y-%m-%d_%H:%M:%s')
            name = f'{lane_code}_{date_component}.jpg'
            return_filename = os.path.join(self.template_camera_path, name)
            cv2.imwrite(return_filename, frame)

            # load the frame and encode it as base64
            plate_img = open(return_filename, 'rb')
            frame = plate_img.read()
            encode_image = base64.b64encode(frame).decode()

            # save it on the cache for later use
            runtime_cache.runtime_data_cache.set_variable(name=LAST_IMAGE_PLATE, data=encode_image)
            return_code = response_codes.CAMERA_SUCCESS

            logger.info(f'++++ frame saved: "{return_filename}"')

        except Exception as ex:
            logger.error(f'Error in AlprCamera module while taking and saving the image : {ex}')
            return_code = response_codes.CAMERA_UNKNOWN_ERROR

        return return_code
