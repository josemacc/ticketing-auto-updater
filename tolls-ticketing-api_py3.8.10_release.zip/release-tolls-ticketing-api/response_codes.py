#!/usr/bin/env python

SUCCESS = '9000'
OBJECT_DOES_NOT_EXIST = '9001'
MULTIPLE_OBJECTS_RETURNED = '9002'
UNEXPECTED_ERROR = '9999'

# General
INVALID_REQUEST_PARAMETERS = '9700'
SERVICE_NOT_AVAILABLE = '9701'
INVALID_DATA = '9702'

DEFAULT_MESSAGE_CODE = 'Error indefinido'
TAG_SUCCESS = 'Entrada por tag exitosa'

# Printer Errors
PRINTER_IDLE = '8000'
PRINTER_BUSY = '8001'
PRINTER_NOT_CONNECTED = '8103'
PRINTER_NO_PAPER = '8101'
PRINTER_PAPER_JAMMED = '8102'
PRINTER_UNKNOWN_ERROR = '8100'

# Antenna
INVALID_TAG = '9101'
INVALID_TAG_IN_TOLL = '9110'
INSUFFICIENT_FUND = '9104'
INVALID_NODE = '9102'

CONNECTION_ERROR = '9106'
# Camera Errors
CAMERA_SUCCESS = '7000'
CAMERA_UNKNOWN_ERROR = '7100'
CAMERA_NOT_CONNECTED = '7103'


MESSAGE_CODES = {
    # General
    SUCCESS: 'Operación Exitosa',
    UNEXPECTED_ERROR: 'Error procesando tarjeta',

    OBJECT_DOES_NOT_EXIST: 'Objeto no encontrado',
    MULTIPLE_OBJECTS_RETURNED: 'Múltiples objetos encontrados',

    INVALID_REQUEST_PARAMETERS: 'Parámetros de llamada no válidos',
    SERVICE_NOT_AVAILABLE: 'Error de conexión con el servidor',

    # Tags
    INVALID_TAG: 'Tag no registrado',
    INVALID_TAG_IN_TOLL: 'Este tipo de vehiculo no es permitido',
    INSUFFICIENT_FUND: 'Fondo insuficiente',
    INVALID_NODE: 'Nodo no registrado',

    # Printer
    PRINTER_IDLE: 'Impresión exitosa/Impresora desocupada',
    PRINTER_BUSY: 'Impresora ocupada con otra tarea',
    PRINTER_NOT_CONNECTED: 'Impresora no conectada',
    PRINTER_NO_PAPER: 'Impresora sin papel',
    PRINTER_PAPER_JAMMED: 'Impresora con papel atorado',
    PRINTER_UNKNOWN_ERROR: 'Erro desconocido con la impresora',
}


def error_description(error_code):
    return MESSAGE_CODES.get(error_code, DEFAULT_MESSAGE_CODE)


if __name__ == '__main__':
    import sys
    print('=== Mensajes de error "TICKETING" ===')

    def print_usage_and_exit():
        import os
        filename = os.path.split(sys.argv[0])[1]
        print(f'Uso:\n   {filename} <error_code>\n')
        exit(-1)

    if len(sys.argv) == 2:
        err_code = sys.argv[1]
        if len(err_code) != 4:
            print_usage_and_exit()
        else:
            if err_code in MESSAGE_CODES:
                print(f'El error_code={err_code} es "{MESSAGE_CODES[err_code]}"')
            else:
                print(f'El error_code={err_code} no se encuentra definido')
    else:
        print_usage_and_exit()
