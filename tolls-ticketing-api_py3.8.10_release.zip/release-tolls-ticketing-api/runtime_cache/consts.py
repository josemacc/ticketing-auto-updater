SYSTEM_STATE = 'system_state'
SYSTEM_NOTIFICATIONS = 'system_notifications'
WEB_CONFIG = 'web_config'
OPERATOR_INFO = 'operator_info'
TOLL_SITE_INFO = 'toll_site_info'
COMPANY_INFO = 'company_info'
NODE_INFO = 'node_info'
LANE_INFO = 'lane_info'
IS_USER_LOGGED_IN = 'is_user_logged_in'
LAST_IMAGE_PLATE = 'last_image_plate'

TRANSIT_COUNTER = 'transit_counter'

# Updates and versions
REGIONAL_BUILD_VERSION = 'regional_build_version'
