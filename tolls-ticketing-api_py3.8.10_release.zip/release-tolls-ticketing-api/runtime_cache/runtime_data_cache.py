import threading

from .consts import SYSTEM_STATE, WEB_CONFIG, OPERATOR_INFO, COMPANY_INFO, NODE_INFO, IS_USER_LOGGED_IN, \
    REGIONAL_BUILD_VERSION, TOLL_SITE_INFO, LAST_IMAGE_PLATE, SYSTEM_NOTIFICATIONS, TRANSIT_COUNTER

from common_consts import WORK_SHIFT_KEY, WORK_PERIOD_KEY

data_lock = threading.Lock()


def generate_runtime_data():
    return {
        SYSTEM_STATE: {},
        SYSTEM_NOTIFICATIONS: None,
        WEB_CONFIG: None,
        TOLL_SITE_INFO: {},
        OPERATOR_INFO: {},
        COMPANY_INFO: {},
        NODE_INFO: {},
        LAST_IMAGE_PLATE: None,
        IS_USER_LOGGED_IN: False,

        REGIONAL_BUILD_VERSION: '<not set>',

        WORK_SHIFT_KEY: None,
        WORK_PERIOD_KEY: None,

        TRANSIT_COUNTER: None
    }


runtime_data = generate_runtime_data()


class VariableNotDefined(Exception):
    pass


def set_variable(name, data, use_lock=True):
    if use_lock:
        data_lock.acquire()

    try:
        runtime_data[name] = data
    except KeyError:
        raise VariableNotDefined(f'Variable "{name}" not defined in runtime data cache doing a set_variable')
    finally:
        if use_lock:
            data_lock.release()


def get_variable(name, use_lock=True):
    if use_lock:
        data_lock.acquire()

    try:
        return runtime_data.get(name)
    except KeyError:
        raise VariableNotDefined(f'Variable "{name}" not defined in runtime data cache doing a get_variable')
    finally:
        if use_lock:
            data_lock.release()


def clean_runtime_cache():
    global runtime_data
    runtime_data = generate_runtime_data()
