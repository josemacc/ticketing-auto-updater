# Values for TRUE
VALUES_FOR_TRUE = ['1', 'true', True, 'y']
VALUES_FOR_FALSE = ['0', 'false', False, 'n']

# Node
NODE_CODE_KEY = 'node_code'
NODE_TYPE_KEY = 'node_type'
COMPANY_CODE_KEY = 'company_code'

# Request types
GET = ['get']
POST = ['post']

# Request/Response types
JSON_MIME_TYPE = 'application/json'
TEXT_MIME_TYPE = 'text/plain'

# Request/Response keys
INCLUDE_USER_INFO_KEY = 'includeUserInfo'
INCLUDE_WEB_CONFIG_KEY = 'includeWebConfig'

WEB_CONFIG_KEY = 'web_config'
USER_INFO_KEY = 'user_info'
MASTER_NUMBERS_KEY = 'master_numbers'

FARE_PRODUCTS_KEY = 'fare_products'

GATE_MODE_KEY = 'gate_mode'
GATE_MODE_REQUEST_KEYS = {GATE_MODE_KEY}

BUILD_VERSION_LOCAL_KEY = 'build-version-local'
BUILD_VERSION_REMOTE_KEY = 'build-version-remote'

WORK_SHIFT_KEY = 'work_shift'
WORK_PERIOD_KEY = 'work_period'

VALID_PAYMENT_METHODS_KEY = 'valid_payment_methods'

LAST_IMAGE_PLATE = 'last_image_plate'

# Login request
USERNAME_KEY = 'username'
PASSWORD_KEY = 'password'

# Logging
MESSAGE_DONE_SUFFIX = '_done'

# State machine
PRINTER_STATUS_KEY = 'printer_status'

# Gate operations for "gate_call_and_wait"
OPERATION_STATE__GET = 'GET_STATE'
OPERATION_STATE__SET = 'SET_STATE'

# Payment methods
PAYMENT_METHODS_STR = {
    'cash': 'Efectivo',
    'debit/credit': 'Débito/Crédito',
    'post-payment': 'Post Pago',
}

# Currencies
# https://en.wikipedia.org/wiki/ISO_4217

VENEZUELAN_VES_ISO_CODE = '928'
DOLLAR_USD_ISO_CODE = '840'
# EURO_ISO_CODE = '978'
COLOMBIAN_PESO_ISO_CODE = '170'
DEBIT_CARD_PSEUDO_ISO_CODE = 'DEBIT'

SUPPORTED_CURRENCIES = [VENEZUELAN_VES_ISO_CODE, DOLLAR_USD_ISO_CODE,
                        # EURO_ISO_CODE,
                        COLOMBIAN_PESO_ISO_CODE, DEBIT_CARD_PSEUDO_ISO_CODE]

CASH_METHOD = 'cash'
DEBIT_CREDIT_METHOD = 'debitCredit'
SUPPORTED_CLOSE_PERIOD_PAYMENT_METHODS = [CASH_METHOD, DEBIT_CREDIT_METHOD]

# Login type
LOGIN_TYPE_REMOTE = 'login_type_remote'  # authenticated on Regional
LOGIN_TYPE_LOCAL = 'login_type_local'  # authenticated on the local DB

# Printing
PRINTING_OPERATION_KEY = 'operation'
PRINTING_OPERATION_RETRY = 'retry'
PRINTING_OPERATION_CANCEL = 'cancel'

DICT_TRANSLATE = {
    'AUTO': 'automático',
    'MANUAL': 'manual',
    'FREE': 'libre',
    'TAG': 'tag'
}

# Report
TAG_UID = 'tag_id'
PLATE = 'plate'
REASON = 'reason'
