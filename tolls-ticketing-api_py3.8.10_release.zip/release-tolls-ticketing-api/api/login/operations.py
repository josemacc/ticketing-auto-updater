import json
from datetime import datetime
from typing import Optional

from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.hashers import make_password
from rolepermissions.roles import assign_role, clear_roles

from api.models import LastLoginResponse
from common_consts import USERNAME_KEY, PASSWORD_KEY, NODE_TYPE_KEY, NODE_CODE_KEY, COMPANY_CODE_KEY, \
    INCLUDE_WEB_CONFIG_KEY, MASTER_NUMBERS_KEY, WORK_SHIFT_KEY, WORK_PERIOD_KEY, FARE_PRODUCTS_KEY, \
    VALID_PAYMENT_METHODS_KEY

import response_codes
import tolls_ticketing_proj.settings as app_settings
from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait
from runtime_cache import consts as runtime_const
from runtime_cache import runtime_data_cache


from logger import get_logger
logger = get_logger()


def remote_login(username, password):
    success, result = api_call_and_wait('regional/login', {
        USERNAME_KEY: username,
        PASSWORD_KEY: password,
        NODE_TYPE_KEY: app_settings.NODE_TYPE,
        NODE_CODE_KEY: app_settings.NODE_CODE,
        COMPANY_CODE_KEY: app_settings.COMPANY_CODE,
        INCLUDE_WEB_CONFIG_KEY: True,
    })

    user_instance = None
    employee_info = None
    user_created = False

    # Success login, create the local user
    if success and type(result) == dict:
        try:
            # Operator info
            employee_info = result.get('employee_info')
            first_name = employee_info.get('first_name')
            last_name = employee_info.get('last_name')
            email = employee_info.get('email')
            # phone_number = user_info.get('phone_number')

            # Get or create the local username and update its password
            try:
                user_instance = User.objects.get(username=username)
                user_instance.password = make_password(password)
            except ObjectDoesNotExist:
                user_instance = None

            if not user_instance:
                user_instance = User.objects.create_user(
                    username, password=make_password(password),
                    first_name=first_name, last_name=last_name,
                    email=email)
                user_created = True
            user_instance.save()

            # Remove old roles and assign the new role
            clear_roles(user_instance)

            remote_role = result.get('role')
            if remote_role and type(remote_role) == str and len(remote_role) > 0:
                assign_role(user_instance, remote_role)
            else:
                raise Exception('No roles from the remote login')

            update_cache_with_login_data(result)

            save_user_result = save_login_response(user_instance, result)
            if not save_user_result:
                raise Exception('LastLoginResponse not saved')

        except Exception as e:
            logger.error(f'Could not create the local user: {str(e) or type(e).__name__}')
            if user_created:
                User.objects.get(username=username).delete()

            user_instance = None
            employee_info = None

    return user_instance, employee_info


def cache_login(username, password):
    user_instance = authenticate(username=username, password=password)
    if user_instance:
        result = load_login_response(user_instance)
        update_cache_with_login_data(result)
        employee_info = result.get('employee_info')

    else:
        employee_info = None

    return user_instance, employee_info


def remote_logout(work_shift, work_period):
    try:
        work_shift = int(work_shift)
        work_period = int(work_period)
    except (ValueError, TypeError):
        work_shift = None
        work_period = None

    success, data = api_call_and_wait('regional/logout', {
        'work_shift': work_shift,
        'work_period': work_period
    })
    result = None

    if not success:
        logger.error(f'Error in remote_logout while logging-out from Regional')

    elif success and type(data) == dict:
        result_code = data.get('result_code')
        report_data = data.get('report_data')

        if result_code == response_codes.SUCCESS:
            result = report_data
        else:
            message = response_codes.error_description(result_code)
            logger.error(f'Error in remote_logout: Response from Regional is "{message}" ({result_code})')
    else:
        logger.error(f'Error in remote_logout: The response is not dict')

    return result


def save_login_response(user_instance: User, response: dict) -> bool:
    try:
        response_str = json.dumps(response, default=str)
    except Exception as ex0:
        logger.error(f'Error in save_login_response while serializing the response: {ex0}')
        return False

    try:
        last_login = LastLoginResponse.objects.get(user__username=user_instance.username)
        last_login.created_on = datetime.now()
        last_login.response = response_str
        last_login.save()
        return True

    except ObjectDoesNotExist:
        try:
            last_login = LastLoginResponse(user=user_instance, response=response_str)
            last_login.save()
            return True
        except Exception as ex1:
            logger.error(f'Error in save_login_response while creating the user: {ex1}')

    except Exception as ex2:
        logger.error(f'Error in save_login_response while updating the user: {ex2}')

    return False


def load_login_response(user_instance: User) -> Optional[dict]:
    try:
        last_login = LastLoginResponse.objects.get(user__username=user_instance.username)
        response = json.loads(last_login.response)
        return response

    except ObjectDoesNotExist:
        return None

    except Exception as ex:
        logger.error(f'Error in load_login_response: {ex}')
        return None


def update_cache_with_login_data(result: dict):
    # Login
    employee_info = result.get('employee_info')
    runtime_data_cache.set_variable(runtime_const.OPERATOR_INFO, employee_info)
    runtime_data_cache.set_variable(runtime_const.IS_USER_LOGGED_IN, True, False)

    # Site info
    toll_site_info = result.get('site_info')
    runtime_data_cache.set_variable(runtime_const.TOLL_SITE_INFO, toll_site_info)

    # Node info
    node_info = result.get(runtime_const.NODE_INFO)
    runtime_data_cache.set_variable(runtime_const.NODE_INFO, node_info)

    # Lane info
    lane_info = result.get(runtime_const.LANE_INFO)
    runtime_data_cache.set_variable(runtime_const.LANE_INFO, lane_info)

    # Company info
    company_info = result.get(runtime_const.COMPANY_INFO)
    runtime_data_cache.set_variable(runtime_const.COMPANY_INFO, company_info)

    # Fare Products
    fare_products = result.get(FARE_PRODUCTS_KEY)
    runtime_data_cache.set_variable(FARE_PRODUCTS_KEY, fare_products)

    # Regional Server Build Version
    regional_build_version = result.get('build_version', '<error>')
    runtime_data_cache.set_variable(runtime_const.REGIONAL_BUILD_VERSION, regional_build_version)

    # Shift and Period
    master_numbers = result.get(MASTER_NUMBERS_KEY)
    if type(master_numbers) != dict:
        raise Exception(f'Error in login: '
                        f'Field master_documents is missing or incorrect on the response from Regional')

    try:
        work_shift = int(master_numbers.get('work_shift'))
        work_period = int(master_numbers.get('work_period'))
    except Exception:
        raise Exception('Unable to parse work_shift/work_period from the remote login response')

    runtime_data_cache.set_variable(WORK_SHIFT_KEY, work_shift)
    runtime_data_cache.set_variable(WORK_PERIOD_KEY, work_period)

    # Valid payment methods
    valid_payment_methods = result.get(VALID_PAYMENT_METHODS_KEY)
    runtime_data_cache.set_variable(VALID_PAYMENT_METHODS_KEY, valid_payment_methods)

    # Regional version
    regional_build_version = result.get('build_version', '<error>')
    runtime_data_cache.set_variable(runtime_const.REGIONAL_BUILD_VERSION, regional_build_version)
