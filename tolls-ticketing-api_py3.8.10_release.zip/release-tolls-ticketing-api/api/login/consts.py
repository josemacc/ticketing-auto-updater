# Session
CSRFTOKEN_PARAM_NAME = 'csrftoken'

# Exception errors
USER_NOT_FOUND_MESSAGE_FMT = 'Could not find the user. The exception is: {0}'
ERROR_LOGGING_USER_IN_MESSAGE_FMT = 'An exception occurred logging the user in. The exception is: {0}'

# User messages
MESSAGE_INVALID_LOGIN = 'MESSAGE_INVALID_LOGIN'
MESSAGE_CANNOT_LOGIN = 'USER_DISABLED'
MESSAGE_INVALID_COMMAND_ERROR = 'INVALID_COMMAND'

# Misc
NEXT_PARAM_NAME = 'next'
