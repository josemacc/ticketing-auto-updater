from django.contrib.sessions.models import Session

from logger import get_logger
logger = get_logger()


def cleanup_sessions():
    Session.objects.all().delete()

    # Clear the Runtime cache
    from runtime_cache import runtime_data_cache, consts as runtime_const
    runtime_data_cache.set_variable(runtime_const.WEB_CONFIG, None)
    runtime_data_cache.clean_runtime_cache()

    logger.debug(f'cleanup_sessions done')
