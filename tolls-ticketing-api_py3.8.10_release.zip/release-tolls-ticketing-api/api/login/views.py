import json
import time

from django.contrib.auth import login as django_login, logout as django_logout
from django.http import HttpResponse, HttpResponseForbidden
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.core.exceptions import ObjectDoesNotExist

from common_consts import USERNAME_KEY, PASSWORD_KEY, INCLUDE_WEB_CONFIG_KEY, VALUES_FOR_TRUE, USER_INFO_KEY, \
    WEB_CONFIG_KEY, JSON_MIME_TYPE, LOGIN_TYPE_REMOTE, LOGIN_TYPE_LOCAL

from api.login import consts as login_consts
from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait
from runtime_cache import consts as runtime_const
from runtime_cache import runtime_data_cache
from tolls_ticketing_proj import settings
from . import operations as login_operations
from .utils import cleanup_sessions
from api.models import TransitCounter

from dispatcher_module.events.fsm_events import StateMachineOperatorLogin
from modules import post_event

from logger import get_logger
logger = get_logger()


@require_POST
@csrf_exempt
def login(request):
    try:
        request_data = json.loads(request.body)
    except json.JSONDecodeError:
        request_data = {}

    username = request_data.get(USERNAME_KEY)
    password = request_data.get(PASSWORD_KEY)

    if username:
        username = str(username).strip()

    if password:
        password = str(password)

    if not username or not password:
        return HttpResponseForbidden(login_consts.MESSAGE_INVALID_LOGIN)

    cleanup_sessions()

    # Try the remote login
    user, operator_info = login_operations.remote_login(username, password)

    # Try the cached login
    if user:
        login_type = LOGIN_TYPE_REMOTE
    else:
        user, operator_info = login_operations.cache_login(username, password)
        if user:
            login_type = LOGIN_TYPE_LOCAL
        else:
            login_type = None

    if user is not None:
        django_login(request, user)
        logger.info(f'Login type: {login_type}')

        # Include the web_config if requested
        include_web_config = request_data.get(INCLUDE_WEB_CONFIG_KEY) in VALUES_FOR_TRUE

        if include_web_config:
            from api.web_config import views as web_config_views
            web_config_data = web_config_views.WebConfigViewSet.get_web_config(request)

            data = {
                USER_INFO_KEY: operator_info,
                WEB_CONFIG_KEY: web_config_data
            }
        else:
            data = operator_info

        # Bring the FSM to the login state
        post_event(StateMachineOperatorLogin())
        time.sleep(0.2)

        # Load the transit counter
        try:
            counter_data = TransitCounter.objects.get(mode='default')
            counter_value = counter_data.counter

        except ObjectDoesNotExist:
            counter_value = None

        except Exception as ex:
            counter_value = None
            logger.error(f'Error in login while loading the local transit counter: {ex}')

        runtime_data_cache.set_variable(runtime_const.TRANSIT_COUNTER, counter_value)

        # Response
        data_str = json.dumps(data)
        return HttpResponse(data_str, content_type=JSON_MIME_TYPE)

    return HttpResponseForbidden(login_consts.MESSAGE_INVALID_LOGIN)


@require_POST
@csrf_exempt
def logout(request):
    # Clear cache
    runtime_data_cache.set_variable(runtime_const.IS_USER_LOGGED_IN, False, False)
    runtime_data_cache.set_variable(runtime_const.OPERATOR_INFO, {}, False)
    runtime_data_cache.set_variable(runtime_const.COMPANY_INFO, {}, False)

    # Clear local transit counter
    try:
        counter_data = TransitCounter.objects.get(mode='default')
        counter_data.counter = counter_value = 0
        counter_data.save()

        if settings.DISABLE_CONNECTION_DEVICE:
            pass

        else:
            success, _ = api_call_and_wait('gate_device/reset_counters', {})
            if success:
                logger.warning('The counters in the gate device have been reset')
            else:
                logger.warning('Error in logout while calling the gate device to reset the counters')

    except ObjectDoesNotExist:
        counter_value = 0
        counter_data = TransitCounter(mode='default', counter=counter_value)
        counter_data.save()

    except Exception as ex:
        counter_value = None
        logger.error(f'Error in logout while resetting the local transit counter: {ex}')

    runtime_data_cache.set_variable(runtime_const.TRANSIT_COUNTER, counter_value)

    # Cleanup session
    django_logout(request)
    cleanup_sessions()
    request.session.clear()

    # Bring the FSM to the login state
    post_event(StateMachineOperatorLogin())
    time.sleep(0.2)

    response = HttpResponse()
    response.set_cookie(login_consts.CSRFTOKEN_PARAM_NAME, '')

    return response
