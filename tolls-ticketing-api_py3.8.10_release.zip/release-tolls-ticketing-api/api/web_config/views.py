from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK
from rest_framework.viewsets import GenericViewSet

from api.runtime_endpoints.operations import get_gate_mode
from common_consts import POST, VALUES_FOR_TRUE, INCLUDE_USER_INFO_KEY, WEB_CONFIG_KEY, USER_INFO_KEY, \
    MASTER_NUMBERS_KEY, BUILD_VERSION_LOCAL_KEY, BUILD_VERSION_REMOTE_KEY, WORK_SHIFT_KEY, WORK_PERIOD_KEY, \
    FARE_PRODUCTS_KEY, VALID_PAYMENT_METHODS_KEY, GATE_MODE_KEY

from tolls_ticketing_proj import settings
from runtime_cache import consts as runtime_const
from runtime_cache import runtime_data_cache
from api.roles_n_permissions import consts as permissions
from rest_framework_rolepermissions import has_permission_decorator


class WebConfigViewSet(GenericViewSet):
    name = 'WebConfigView'

    @action(methods=POST, url_path='web-config', detail=False)
    @has_permission_decorator(permissions.RETRIEVE_WEB_CONFIG)
    def retrieve_data(self, request):
        include_user_info = request.data.get(INCLUDE_USER_INFO_KEY) in VALUES_FOR_TRUE
        web_config_data = WebConfigViewSet.get_web_config(request)

        if include_user_info:
            operator_info = runtime_data_cache.get_variable(runtime_const.OPERATOR_INFO)
            web_config_data = {
                WEB_CONFIG_KEY: web_config_data,
                USER_INFO_KEY: operator_info
            }

        return Response(data=web_config_data, status=HTTP_200_OK)

    # noinspection PyUnusedLocal
    @staticmethod
    def get_web_config(request):
        with runtime_data_cache.data_lock:
            web_config = runtime_data_cache.get_variable(runtime_const.WEB_CONFIG, False)

            if web_config is None:
                node_info = runtime_data_cache.get_variable(runtime_const.NODE_INFO, False)
                lane_info = runtime_data_cache.get_variable(runtime_const.LANE_INFO, False)
                company_info = runtime_data_cache.get_variable(runtime_const.COMPANY_INFO, False)
                fare_products = runtime_data_cache.get_variable(FARE_PRODUCTS_KEY, False)
                valid_payment_methods = runtime_data_cache.get_variable(VALID_PAYMENT_METHODS_KEY, False)
                regional_build_version = runtime_data_cache.get_variable(runtime_const.REGIONAL_BUILD_VERSION, False)

                web_config = {
                    runtime_const.NODE_INFO: node_info,
                    runtime_const.LANE_INFO: lane_info,
                    runtime_const.COMPANY_INFO: company_info,
                    FARE_PRODUCTS_KEY: fare_products,
                    VALID_PAYMENT_METHODS_KEY: valid_payment_methods,
                    BUILD_VERSION_LOCAL_KEY: settings.BUILD_VERSION,
                    BUILD_VERSION_REMOTE_KEY: regional_build_version,

                    'fsmToRoute': {
                        'st_init': '/non-operative',
                        'st_non_operative': '/non-operative',
                        'st_vehicle_type_selection': '/vehicle-type-selection',
                        'st_print_receipt': '/print-receipt',
                        'st_print_receipt_error': '/print-receipt-error',
                        'st_open_gate': '/open-gate',
                        'st_wait_print_receipt_order': '/print-confirmation',
                        'st_print_close_period': '/print-receipt',
                        'st_print_close_period_error': '/print-receipt-error',
                        'logout': '/logout',
                    },
                    'defaultFmsRoute': '/invalid-state'
                }

                runtime_data_cache.set_variable(runtime_const.WEB_CONFIG, web_config, False)

        master_numbers_data = {
            WORK_SHIFT_KEY: runtime_data_cache.get_variable(WORK_SHIFT_KEY, False),
            WORK_PERIOD_KEY: runtime_data_cache.get_variable(WORK_PERIOD_KEY, False),
        }
        gate_mode = get_gate_mode()

        web_config.update({
            MASTER_NUMBERS_KEY: master_numbers_data,
            GATE_MODE_KEY: gate_mode,
        })
        return web_config
