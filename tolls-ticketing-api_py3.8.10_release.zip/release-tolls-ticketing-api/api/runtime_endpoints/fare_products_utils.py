import datetime

import common_consts
from api.models.offline_mode_models import RegisteredPayment
from runtime_cache import consts as runtime_const
from runtime_cache import runtime_data_cache
from common_consts import FARE_PRODUCTS_KEY, WORK_SHIFT_KEY, WORK_PERIOD_KEY

from logger import get_logger
logger = get_logger()


def fare_product_data_from_id(fare_product_id: str):
    fare_products = runtime_data_cache.get_variable(FARE_PRODUCTS_KEY) or []

    for item in fare_products:
        if fare_product_id == item['id']:
            car_category = item['category']
            nominal_amount = item['nominal_amount']
            nominal_iso_code = item['nominal_iso_code']
            weight_factor = item['weight_factor']
            return car_category, nominal_amount, nominal_iso_code, weight_factor

    return None, None, None, None


def generate_report_data_from_localdb_and_operator_data(data, user):
    result = None
    operator_amount = {}

    if user and user.is_authenticated:
        local_payments = None
        data_by_payment_method = {}
        try:
            # The amounts registered by the system in this period
            local_payments = RegisteredPayment.objects.filter(user__username=user.username)
            for item in local_payments:
                payment_method = item.payment_method
                total_amount = float(item.total_amount)
                if total_amount == 0.0:
                    # skip exonerated
                    continue

                key = payment_method
                if key in data_by_payment_method.keys():
                    item_data = data_by_payment_method[payment_method]
                    item_data['amount'] += total_amount
                    item_data['count'] += 1

                else:
                    data_by_payment_method[key] = {'amount': total_amount, 'count': 1}

            # The amounts specified by the operator in the collected UI form
            if type(data) == dict:
                operator_amount = data

            # Prepare the final data
            shift_date = datetime.datetime.now()
            site_info = runtime_data_cache.get_variable(runtime_const.TOLL_SITE_INFO)
            lane_info = runtime_data_cache.get_variable(runtime_const.LANE_INFO)
            work_shift = runtime_data_cache.get_variable(WORK_SHIFT_KEY)
            work_period = runtime_data_cache.get_variable(WORK_PERIOD_KEY)

            result = {
                'date': shift_date,
                'username': user.username,
                'shift_id': work_shift,
                'period_id': work_period,
                'site': site_info.get('name') if site_info else None,
                'lane': lane_info.get('name') if lane_info else None,
                'nominal_by_iso_code': common_consts.VENEZUELAN_VES_ISO_CODE,
                'data_by_payment_method': data_by_payment_method,
                'operator_data_payment': operator_amount
            }

        except Exception as ex:
            logger.error(f'Error in generate_report_data_from_localdb_and_operator_data: {ex}')
            result = None

        # We're closing this period, clear the data registered by the system so far
        try:
            if local_payments:
                local_payments.delete()
        except Exception as ex:
            logger.error(f'Error in generate_report_data_from_localdb_and_operator_data '
                         f'while deleting local payments: {ex}')

    return result
