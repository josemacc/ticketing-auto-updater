from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.viewsets import GenericViewSet

import response_codes
from api.models import consts as models_consts
from api.roles_n_permissions import consts as permissions
from common_consts import POST, GATE_MODE_KEY, GATE_MODE_REQUEST_KEYS, PRINTING_OPERATION_KEY, \
    PRINTING_OPERATION_CANCEL, PRINTING_OPERATION_RETRY
from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait
from dispatcher_module.events import fsm_events, camera_event
from dispatcher_module.events.fsm_events import StateMachineEventPrintConfirmation
from exceptions import TicketingException
from logger import get_logger
from modules import post_event
from rest_framework_rolepermissions import has_permission_decorator
from tolls_ticketing_proj import settings
from .operations import set_gate_mode, retry_or_cancel_printing, close_period_before_logout, register_payment, \
    get_gate_mode, report_tag_to_gate_device
import subprocess
logger = get_logger()


class RuntimeEndpointsViewSet(GenericViewSet):
    name = 'RuntimeEndpointsViewSet'

    @action(methods=POST, detail=False, url_path='register-payment')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def register_payment(self, request):
        request_user = request.user
        request_data = request.data
        response = register_payment(request_user, request_data)
        return Response(response)

    @action(methods=POST, detail=False, url_path='vehicle-selected')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def vehicle_selected(self, request):
        logger.info(f'+++++++++ ENDPOINT vehicle_selected')
        data = request.data
        category = data.get('category')
        post_event(camera_event.GetLicensePlate(category))
        response = {
            'return_code': response_codes.SUCCESS
        }
        return Response(response)

    @action(methods=POST, detail=False, url_path='open-gate-no-payment')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def open_gate_no_payment(self, request):
        if settings.DISABLE_CONNECTION_DEVICE:
            return_code = response_codes.SUCCESS

        else:
            # TODO: esto reemplazara todo el código aquí
            # success, return_code, _ = gate_call_and_wait(OPERATION_STATE__SET, {'new_state': GATE_STATE_OPEN})

            params = {
                'trigger': 'cmd_open_gate',
                'mode': 'open',
                'transit_data': {}
            }

            success, result = api_call_and_wait('gate_device/action', params)
            return_code = response_codes.UNEXPECTED_ERROR

            if success:
                if type(result) == dict:
                    return_code = result.get('return_code')
                    if not return_code:
                        return_code = response_codes.UNEXPECTED_ERROR
                        logger.warning('Warning calling de Gate device: No return_code returned from the device')

            if return_code == response_codes.SUCCESS:
                logger.info(f'Success calling de Gate device to OPEN the gate')
            else:
                logger.error(f'Error calling de Gate device to OPEN the gate: return_code="{return_code}"')

        response = {
            'return_code': return_code
        }
        return Response(response)

    @action(methods=POST, detail=False, url_path='close-gate')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def close_gate(self, request):
        if settings.DISABLE_CONNECTION_DEVICE:
            return_code = response_codes.SUCCESS

        else:
            # TODO: Esto reemplazará todo el código aquí
            # success, return_code, _ = gate_call_and_wait(OPERATION_STATE__SET, {'new_state': GATE_STATE_OPEN})

            # current_gate_mode = get_gate_mode()
            params = {
                'trigger': 'cmd_close_gate',
                'mode': 'close'
            }

            success, result = api_call_and_wait('gate_device/action', params)
            return_code = response_codes.UNEXPECTED_ERROR

            if success:
                if type(result) == dict:
                    return_code = result.get('return_code')
                    if not return_code:
                        return_code = response_codes.UNEXPECTED_ERROR
                        logger.warning('Warning in close_gate: No return_code returned from the device')

            if return_code == response_codes.SUCCESS:
                logger.info(f'Success calling the Gate device to CLOSE the gate')
            else:
                logger.error(f'Error calling de Gate device to CLOSE the gate: return_code="{return_code}"')

        response = {
            'return_code': return_code
        }
        return Response(response)

    @action(methods=POST, detail=False, url_path='ticketing-gate-mode')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def ticketing_gate_mode(self, request):
        try:
            # Capture the input parameters
            request_data = request.data
            keys = set(request_data.keys())

            if keys != GATE_MODE_REQUEST_KEYS:
                raise TicketingException(
                    return_code=response_codes.INVALID_REQUEST_PARAMETERS)

            gate_mode = request_data.get(GATE_MODE_KEY)
            if gate_mode not in models_consts.GATE_MODE_CHOICES_KEYS:
                raise TicketingException(
                    return_code=response_codes.INVALID_REQUEST_PARAMETERS, reason='Invalid gate_mode')

            return_code = response_codes.SUCCESS
            set_gate_mode(gate_mode)

        except TicketingException as ex1:
            ex_return_code = ex1.return_code
            ex_reason = ex1.reason
            if ex_reason:
                logger.info(
                    f'Error in ticketing_gate_mode: return_code="{ex_return_code}" because of "{ex_reason}"')
            else:
                logger.info(
                    f'Error in ticketing_gate_mode: return_code="{ex_return_code}"')
            return_code = ex_return_code

        except Exception as ex:
            logger.error(f'Error in ticketing_gate_mode: {ex}')
            return_code = response_codes.UNEXPECTED_ERROR

        response = {
            'return_code': return_code
        }
        return Response(response)

    @action(methods=POST, detail=False, url_path='tmp-next-state-after-open-gate')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def tmp_next_state_after_open_gate(self, request):
        post_event(fsm_events.StateMachineEvent(data={
            'trigger': 'ev_gate_closed'
        }))

        response = {
            'return_code': response_codes.SUCCESS
        }
        return Response(response)

    @action(methods=POST, detail=False, url_path='retry-or-cancel-printing')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def retry_or_cancel_printing(self, request):
        try:
            # Capture the input parameters
            request_data = request.data
            operation = request_data.get(PRINTING_OPERATION_KEY)

            if operation not in [PRINTING_OPERATION_RETRY, PRINTING_OPERATION_CANCEL]:
                raise TicketingException(
                    return_code=response_codes.INVALID_REQUEST_PARAMETERS, reason='Invalid retry or cancel value')

            retry_or_cancel_printing(operation)
            return_code = response_codes.SUCCESS

        except TicketingException as ex1:
            ex_return_code = ex1.return_code
            ex_reason = ex1.reason
            if ex_reason:
                logger.info(f'Error in retry_or_cancel_printing: return_code="{ex_return_code}" '
                            f'because of "{ex_reason}"')
            else:
                logger.info(
                    f'Error in retry_or_cancel_printing: return_code="{ex_return_code}"')
            return_code = ex_return_code

        except Exception as ex:
            logger.error(f'Error in retry_or_cancel_printing: {ex}')
            return_code = response_codes.UNEXPECTED_ERROR

        response = {
            'return_code': return_code
        }
        return Response(response)

    @action(methods=POST, detail=False, url_path='close-period-before-logout')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def close_period_before_logout(self, request):
        return_code, return_data = close_period_before_logout(request)

        response = {
            'return_code': return_code,
            'return_data': return_data
        }
        subprocess.call(["sudo", "systemctl", "restart", "apache2"])
        return Response(response)

    @action(methods=POST, detail=False, url_path='print-confirmation')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def print_receipt(self, request):
        print_request = request.data.get('print')

        if print_request is not None:
            post_event(StateMachineEventPrintConfirmation(print_request))
            return_code = response_codes.SUCCESS
        else:
            return_code = response_codes.INVALID_REQUEST_PARAMETERS

        response = {
            'return_code': return_code
        }

        return Response(response)

    @action(methods=POST, detail=False, url_path='return-home')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def return_home(self, request):
        if settings.DISABLE_CONNECTION_DEVICE:
            return_code = response_codes.SUCCESS

        else:
            current_gate_mode = get_gate_mode()
            return_code = response_codes.SUCCESS

            if current_gate_mode != models_consts.MANUAL_MODE:
                params = {
                    'trigger': 'cmd_close_gate',
                    'mode': 'close'
                }

                success, result = api_call_and_wait('gate_device/action', params)
                return_code = response_codes.UNEXPECTED_ERROR

                if success:
                    if type(result) == dict:
                        return_code = result.get('return_code')
                        if not return_code:
                            return_code = response_codes.UNEXPECTED_ERROR
                            logger.warning('Warning in close_gate: No return_code returned from the device')

                if return_code == response_codes.SUCCESS:
                    logger.info(f'Success calling the Gate device to CLOSE the gate')
                else:
                    logger.error(f'Error calling de Gate device to CLOSE the gate: return_code="{return_code}"')

        post_event(fsm_events.StateMachineEvent(data={
            'trigger': 'ev_gate_closed'
        }))

        response = {
            'return_code': return_code
        }
        return Response(response)

    @action(methods=POST, detail=False, url_path='look-for-tag')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def look_for_tag(self, request):
        if settings.DISABLE_CONNECTION_DEVICE:
            return_code = response_codes.SUCCESS

        else:
            success, result = api_call_and_wait('gate_device/look-for-tag', {})
            return_code = response_codes.UNEXPECTED_ERROR

            if success:
                if type(result) == dict:
                    return_code = result.get('return_code')
                    if not return_code:
                        return_code = response_codes.UNEXPECTED_ERROR
                        logger.warning('Warning in look-for-tag: No return_code returned from the device')

            if return_code == response_codes.SUCCESS:
                logger.info(f'Success calling the Gate device to look for a tag')
            else:
                logger.error(f'Error calling de Gate device to look for a tag: return_code="{return_code}"')

        response = {
            'return_code': return_code
        }
        return Response(response)

    @action(methods=POST, detail=False, url_path='report-tag')
    @has_permission_decorator(permissions.DO_TICKETING_OPERATIONS)
    def report_tag(self, request):
        if settings.DISABLE_CONNECTION_DEVICE:
            return_code = response_codes.SUCCESS

        else:
            success, result = report_tag_to_gate_device(request.data)
            return_code = response_codes.UNEXPECTED_ERROR

            if success:
                if type(result) == dict:
                    return_code = result.get('return_code')
                    if not return_code:
                        return_code = response_codes.UNEXPECTED_ERROR
                        logger.warning('Warning in report-tag: No return_code returned from the device')

            if return_code == response_codes.SUCCESS:
                logger.info(f'Success calling the Gate device to report a tag')
            else:
                logger.error(f'Error calling de Gate device to report a tag: return_code="{return_code}"')

        response = {
            'return_code': return_code
        }
        return Response(response)
