import time

from django.core.exceptions import ObjectDoesNotExist
from django.http import QueryDict

import common_consts
import modules.secure_messages.messages_consts as messages_consts
import response_codes
from api.models import TicketingGateMode, consts as models_consts
from api.models import TransitCounter
from api.models.offline_mode_models import RegisteredPayment
from api.runtime_endpoints.fare_products_utils import fare_product_data_from_id, \
    generate_report_data_from_localdb_and_operator_data
from common_consts import WORK_SHIFT_KEY, WORK_PERIOD_KEY
from dispatcher_module.event_dispatcher.api_call_and_wait import api_call_and_wait
from dispatcher_module.events import printer_events
from dispatcher_module.events.fsm_events import StateMachineCloseOperatorPeriod, StateMachinePaymentProcessed
from logger import get_logger
from modules import post_event
from modules.secure_messages.message_queue import post_deferred_message
from runtime_cache import runtime_data_cache, consts as runtime_consts
from tolls_ticketing_proj import settings


logger = get_logger()


def set_gate_mode(gate_mode: str):
    """
    Set the active gate mode on the ticketing.
    Gate modes determine the open/close behaviour of the gate after a successful payment.

    Possible values are defined in "GATE_MODE_CHOICES_KEYS" const: AUTO, SEMI-AUTO and MANUAL
    :param gate_mode: The new gate mode to set
    :exception: The function might rise db exceptions if the data could not be set
    """
    ticketing_gate_mode = _get_object()
    ticketing_gate_mode.mode = gate_mode
    ticketing_gate_mode.save()

    logger.info(f'Changed gate mode to "{gate_mode}"')


def get_gate_mode() -> str:
    """
    Get the active gate mode on the ticketing.
    Gate modes determine the open/close behaviour of the gate after a successful payment.

    Possible values that will be returned are defined in "GATE_MODE_CHOICES_KEYS" const
    :exception: The function might rise db exceptions if the data could not be retrieved
    :return: Current gate mode
    """

    ticketing_gate_mode = _get_object()
    return ticketing_gate_mode.mode


def _get_object() -> TicketingGateMode:
    ticketing_gate_mode = TicketingGateMode.objects.all().first()

    if ticketing_gate_mode is None:
        ticketing_gate_mode = TicketingGateMode(mode=models_consts.DEFAULT_MODE)
        ticketing_gate_mode.save()

    return ticketing_gate_mode


def register_payment_locally(user, request_data: dict):
    try:
        work_shift = runtime_data_cache.get_variable(WORK_SHIFT_KEY)
        work_period = runtime_data_cache.get_variable(WORK_PERIOD_KEY)
        payment_method = request_data.get('payment_method')
        vehicle_weight = request_data.get('vehicle_weight')

        fare_product_id = request_data.get('fare_product_id')
        _, nominal_amount, nominal_iso_code, weight_factor = fare_product_data_from_id(fare_product_id)

        if weight_factor:
            total_amount = request_data.get('weight_factor_payment')
        else:
            total_amount = nominal_amount

        registered_payment = RegisteredPayment(
            user=user,
            fare_product_id=fare_product_id,
            payment_method=payment_method,
            vehicle_weight=vehicle_weight,
            weight_factor=weight_factor,

            nominal_amount=nominal_amount,
            nominal_iso_code=nominal_iso_code,
            total_amount=total_amount,

            work_shift=work_shift,
            work_period=work_period
        )
        registered_payment.save()

    except Exception as ex:
        logger.error(f'Error in register_payment_locally: {ex}')


def retry_or_cancel_printing(operation: str):
    post_event(printer_events.StateMachinePrinterRetryOrCancel(operation))


# def close_period_before_logout(request):
#     work_shift = runtime_data_cache.get_variable(WORK_SHIFT_KEY)
#     work_period = runtime_data_cache.get_variable(WORK_PERIOD_KEY)
#
#     # Remote logout and get the shift close report
#     _ = login_operations.remote_logout(work_shift, work_period)
#     close_period_data = generate_report_data_from_localdb_and_operator_data(request)
#
#     # Print the report
#     if close_period_data:
#         return close_period_data
#
#     else:
#         logger.warning(f'Warning in logout: No data from generate_report_data_from_localdb_and_operator_data')
#         return None
def close_period_before_logout(request):
    user = request.user
    close_period_data = request.data

    if type(close_period_data) in (dict, QueryDict):
        return_code = response_codes.SUCCESS

        # Validate the reported operator amounts
        for method, amount_by_method in close_period_data.items():
            if method not in common_consts.SUPPORTED_CLOSE_PERIOD_PAYMENT_METHODS:
                return_code = response_codes.INVALID_REQUEST_PARAMETERS
                logger.error(f'Error in close_period_before_logout: Invalid payment method "{method}"')
                break

            if type(amount_by_method) == dict:
                for iso_code, amount in amount_by_method.items():
                    if iso_code not in common_consts.SUPPORTED_CURRENCIES:
                        return_code = response_codes.INVALID_REQUEST_PARAMETERS
                        logger.error(f'Error in close_period_before_logout: Invalid iso_code "{iso_code}"')
                        break

                    try:
                        amount = float(amount)
                        if amount < 0:
                            raise Exception('Invalid amount')

                    except Exception as ex:
                        logger.error(f'Error in close_period_before_logout: {ex} for iso_code="{iso_code}"')
                        return_code = response_codes.INVALID_REQUEST_PARAMETERS
                        break

            else:
                logger.warning(f'Warning in close_period_before_logout: method="{method}" has no data')

            if return_code != response_codes.SUCCESS:
                break

        # Notify the FSM about the period closed, post the deferred message and clear local transactions
        if return_code == response_codes.SUCCESS:
            report_data = generate_report_data_from_localdb_and_operator_data(close_period_data, user)
            post_event(StateMachineCloseOperatorPeriod(report_data))
            success = post_deferred_message(messages_consts.MESSAGE_TYPE_REGISTER_CLOSE_PERIOD, report_data)

            if not success:
                return_code = response_codes.UNEXPECTED_ERROR
                logger.error(f'Error in close_period_before_logout while posting the deferred message')

            else:
                # Delete local payments from older approach which saves the payments on the local database
                local_payments = RegisteredPayment.objects.filter(user__username=user.username)
                try:
                    if local_payments:
                        local_payments.delete()
                except Exception as ex:
                    logger.error(f'Error in close_period_before_logout while deleting local payments: {ex}')

    else:
        return_code = response_codes.INVALID_REQUEST_PARAMETERS
        logger.error(f'Error in close_period_before_logout while parsing the parameters')

    return return_code, None


def open_automatic_gate(transit_data: dict) -> str:
    if settings.DISABLE_CONNECTION_DEVICE:
        return response_codes.SUCCESS

    else:
        return_code = response_codes.UNEXPECTED_ERROR
        params = {
            'trigger': 'cmd_open_gate',
            'mode': 'open',
            'transit_data': transit_data or {}
        }
        success, result = api_call_and_wait('gate_device/action', params)

        if success:
            logger.info(f'Success in open_automatic_gate calling the device')

            if type(result) == dict:
                return_code = result.get('return_code')
                if not return_code:
                    logger.warning('Warning in open_automatic_gate: No return_code returned from the device')

                else:
                    if return_code != response_codes.SUCCESS:
                        logger.error(f'Error in open_automatic_gate: return_code={return_code}')

        else:
            logger.error('Error in open_automatic_gate calling the device')

    time.sleep(3)
    return return_code


def get_transit_data_for_gate_device(request_data: dict) -> dict:
    # Operator
    operator_info = runtime_data_cache.get_variable(runtime_consts.OPERATOR_INFO)
    operator_username = (operator_info if type(operator_info) == dict else {}).get('username')
    work_shift = runtime_data_cache.get_variable(WORK_SHIFT_KEY)
    work_period = runtime_data_cache.get_variable(WORK_PERIOD_KEY)

    # Gate operation mode
    operation_mode = get_gate_mode()
    if operation_mode == models_consts.SEMI_AUTO_MODE:
        operation_mode = models_consts.AUTO_MODE
    # Payment details
    payment_method = request_data.get('payment_method')
    vehicle_weight = request_data.get('vehicle_weight')
    plate_image = request_data.get('plate_image')

    fare_product_id = request_data.get('fare_product_id')
    vehicle_category, base_amount, collected_iso_code, weight_factor = fare_product_data_from_id(fare_product_id)

    if type(vehicle_category) != dict:
        logger.error(f'Error in register_payment_on_gate_device: vehicle_category is not dict')
        vehicle_category = {}

    vehicle_category_id = vehicle_category.get('code_category')
    if not vehicle_category_id:
        logger.warning(f'Warning in register_payment_on_gate_device: vehicle_category_id is None')

    if weight_factor:
        collected_amount = request_data.get('weight_factor_payment')
    else:
        collected_amount = base_amount

    # Send the payment info to the gate device
    gate_request_data = {
        'vehicle_category': vehicle_category_id,
        'collected_amount': collected_amount,
        'collected_iso_code': collected_iso_code,
        'weight': vehicle_weight,
        'expected_axles': vehicle_category.get('axles'),
        'real_axles': vehicle_category.get('axles'),
        'flagged': None,
        'requested_by': operator_username,
        'work_shift': work_shift,
        'work_period': work_period,
        'payment_method': payment_method,
        'operation_mode': operation_mode,
        'plate_image': plate_image
    }
    return gate_request_data


def register_transit_manual_gate(transit_data: dict) -> str:
    transit_data = transit_data or {}

    if settings.DISABLE_CONNECTION_DEVICE:
        return_code = response_codes.SUCCESS

    else:
        success, result = api_call_and_wait('gate_device/register_transit', transit_data)

        return_code = response_codes.UNEXPECTED_ERROR
        if success:
            if type(result) == dict:
                return_code = result.get('return_code')
                if not return_code:
                    logger.warning(
                        'Warning in register_transit_manual_gate: No return_code returned from the gate device')
                    return_code = response_codes.UNEXPECTED_ERROR

                else:
                    if return_code != response_codes.SUCCESS:
                        logger.error(f'Error in register_transit_manual_gate: return_code={return_code}')

        else:
            logger.error('Error in register_transit_manual_gate calling the gate device')

    return return_code


def register_payment(request_user, request_data) -> dict:
    # 1. Send the deferred message to Regional
    # TODO: when take the tag id with antenna set in this place and send to regional
    # TODO: Raspberry handles the antenna+tag, probably we don't need this tag_id anymore

    # 1. Get the parameters
    request_data['tag_id'] = None
    last_plate_image = runtime_data_cache.get_variable(runtime_consts.LAST_IMAGE_PLATE)
    request_data['plate_img'] = last_plate_image
    success = post_deferred_message(messages_consts.MESSAGE_TYPE_REGISTER_PAYMENT, request_data)

    if not success:
        logger.error(f'Error in register_payment posting the deferred user')

    # 2. Register the payment locally to be used when closing the period
    register_payment_locally(request_user, request_data)

    # 3. Notify the state machine about the payment
    post_event(StateMachinePaymentProcessed(request_data))

    # 4. Call the device to open the gate and send the transit info with the request
    if settings.DISABLE_CONNECTION_DEVICE:
        pass

    else:
        transit_data = get_transit_data_for_gate_device(request_data)
        gate_mode = get_gate_mode()
        if gate_mode in [models_consts.AUTO_MODE, models_consts.SEMI_AUTO_MODE]:
            _ = open_automatic_gate(transit_data)
        else:
            _ = register_transit_manual_gate(transit_data)

    # 5. Increment the local counter
    try:
        counter_data = TransitCounter.objects.get(mode='default')
        counter_data.counter = counter_value = counter_data.counter + 1
        counter_data.save()
    except ObjectDoesNotExist:
        counter_value = 1
        counter_data = TransitCounter(mode='default', counter=counter_value)
        counter_data.save()

    except Exception as ex:
        counter_value = None
        logger.error(f'Error in register_payment while loading the local transit counter: {ex}')

    runtime_data_cache.set_variable(runtime_consts.TRANSIT_COUNTER, counter_value)

    return_code = response_codes.SUCCESS
    return {
        'return_code': return_code
    }


def report_tag_to_gate_device(data):
    operator_info = runtime_data_cache.get_variable(runtime_consts.OPERATOR_INFO)
    report_data = {
        common_consts.TAG_UID: data.get(common_consts.TAG_UID),
        common_consts.PLATE: data.get(common_consts.PLATE),
        common_consts.USERNAME_KEY: operator_info.get(common_consts.USERNAME_KEY),
        common_consts.REASON: data.get(common_consts.REASON)
    }
    return api_call_and_wait('gate_device/report-tag', report_data)
