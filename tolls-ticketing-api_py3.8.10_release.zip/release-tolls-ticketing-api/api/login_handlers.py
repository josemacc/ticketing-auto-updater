from queue import Queue, Empty

import modules
from dispatcher_module.events.api_caller_events import ApiCallerEvent
from tolls_ticketing_proj import settings


class LoginHandlers:
    def register_handlers(self):
        import modules

        api_caller = modules.current_manager().get_module('api_caller')

        if api_caller:
            api_caller.register_login_handler('gate_device_login_function', self.default_login_function)
            api_caller.register_login_handler('regional_deferred_login_function', self.regional_deferred_login_function)

    # noinspection PyMethodMayBeStatic
    def default_login_function(self, login_info):
        if type(login_info) != dict:
            return False

        response_queue = Queue()

        event_data = {
            'api': login_info.get('api'),
            'return_queue': response_queue,
            'params': {
                'username': login_info.get('username'),
                'password': login_info.get('password')
            },
        }

        ev = ApiCallerEvent(None, event_data)
        modules.current_manager().post_event(ev)

        success = False

        try:
            response = response_queue.get()
            if type(response) == dict:
                success = bool(response.get('success'))
        except Empty:
            pass

        return success

    # noinspection PyMethodMayBeStatic
    def regional_deferred_login_function(self, login_info):
        response_queue = Queue()

        event_data = {
            'api': login_info.get('api'),
            'return_queue': response_queue,
            'params': {
                'username': settings.DEFERRED_API_USER,
                'password': settings.DEFERRED_API_PASSW,
                'company_code': settings.COMPANY_CODE,
                'node_code': settings.NODE_CODE,
                'node_type': settings.NODE_TYPE,
            },
        }

        ev = ApiCallerEvent(None, event_data)
        modules.current_manager().post_event(ev)

        success = False

        try:
            response = response_queue.get()
            if type(response) == dict:
                success = bool(response.get('success'))
        except Empty:
            pass

        return success
