from rolepermissions.roles import AbstractUserRole
from api.roles_n_permissions import consts as permissions


class Operator(AbstractUserRole):
    available_permissions = {
        permissions.DO_TICKETING_OPERATIONS: True,
        permissions.RETRIEVE_WEB_CONFIG: True,
        permissions.SYSTEM_STATE_PERM: True,
    }

    @staticmethod
    def sp_name():
        return 'Operador de Venta'


class Developer(AbstractUserRole):
    available_permissions = {
        permissions.DO_TICKETING_OPERATIONS: True,
        permissions.RETRIEVE_WEB_CONFIG: True,
        permissions.SYSTEM_STATE_PERM: True,
    }

    @staticmethod
    def sp_name():
        return 'Desarrollador'
