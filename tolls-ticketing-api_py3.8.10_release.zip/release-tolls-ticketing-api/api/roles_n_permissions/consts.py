# Permissions module
ROLEPERMISSIONS_MODULE = 'api.roles_n_permissions.ticketing_machine_roles'

# Roles
OPERATOR_ROLE = 'operator'
DEVELOPER_ROLE = 'developer'

# Permissions
DO_TICKETING_OPERATIONS = 'do_ticketing_operations'
RETRIEVE_WEB_CONFIG = 'retrieve_web_config'
SYSTEM_STATE_PERM = 'system_state'
