import os

from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.viewsets import GenericViewSet
from django.views.decorators.csrf import csrf_exempt

from api.roles_n_permissions import consts as permissions
from rest_framework_rolepermissions import has_permission_decorator
from runtime_cache import runtime_data_cache
from runtime_cache import consts as runtime_const
from tolls_ticketing_proj import settings


from logger import get_logger
logger = get_logger()


class SystemEndpointsViewSet(GenericViewSet):
    name = 'SystemEndpointsViewSet'

    @action(methods=('post',), detail=False, url_path='state')
    @has_permission_decorator(permissions.SYSTEM_STATE_PERM)
    def get_state(self, request):
        status = runtime_data_cache.get_variable(runtime_const.SYSTEM_STATE)
        return Response(data=status)

    @action(methods=('post',), detail=False, url_path='notifications')
    @has_permission_decorator(permissions.SYSTEM_STATE_PERM)
    def get_notifications(self, request):
        with runtime_data_cache.data_lock:
            notifications = runtime_data_cache.get_variable(runtime_const.SYSTEM_NOTIFICATIONS, use_lock=False)
            runtime_data_cache.set_variable(runtime_const.SYSTEM_NOTIFICATIONS, None, use_lock=False)

        return Response(data=notifications)

    @csrf_exempt
    @action(methods=('get',), detail=False, url_path='build-version')
    def build_version(self, request):
        regional_build_version = runtime_data_cache.get_variable(
            runtime_const.REGIONAL_BUILD_VERSION)
        data = {
            'build-version-local': settings.BUILD_VERSION,
            'build-version-remote': regional_build_version
        }
        return Response(data=data)

    @csrf_exempt
    @action(methods=('post',), detail=False, url_path='restart-app')
    def restart_app(self, request):
        if settings.RESTART_COMMAND:
            logger.info(f'Restarting server via RESTART_COMMAND...')
            os.system(settings.RESTART_COMMAND)
            success = True
            message = None
        else:
            message = f'No restart server defined in RESTART_COMMAND'
            logger.warning(message)
            success = False

        data = {
            'success': success,
            'message': message
        }
        return Response(data)
