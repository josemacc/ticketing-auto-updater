from rest_framework import routers

from . import views

router = routers.DefaultRouter()
router.register(r'system', views.SystemEndpointsViewSet, basename='system')

urlpatterns = router.urls
