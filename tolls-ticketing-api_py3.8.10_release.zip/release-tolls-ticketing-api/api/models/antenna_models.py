from django.db import models


class TicketingAntennaMessages(models.Model):
    message = models.CharField(max_length=100, null=False, blank=False)
