from django.db import models


class NumTicket(models.Model):
    ticket = models.CharField(primary_key=True, max_length=50, unique=True)
    n_ticket = models.IntegerField(default=1000)
