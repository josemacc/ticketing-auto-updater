from datetime import datetime
from django.db import models
from django.contrib.auth.models import User
from django.db.models import CASCADE


class LastLoginResponse(models.Model):
    user = models.OneToOneField(User, blank=False, null=False, on_delete=CASCADE)
    response = models.CharField(blank=False, null=False, max_length=5000)
    created_on = models.DateTimeField(default=datetime.now)


class RegisteredPayment(models.Model):
    user = models.ForeignKey(User, blank=False, null=False, on_delete=CASCADE)
    fare_product_id = models.CharField(blank=False, null=False, max_length=50)
    payment_method = models.CharField(blank=False, null=False, max_length=20)
    vehicle_weight = models.DecimalField(max_digits=10, decimal_places=2, null=True)
    weight_factor = models.DecimalField(max_digits=10, decimal_places=5, null=True)

    nominal_amount = models.DecimalField(max_digits=10, decimal_places=2, null=False)
    nominal_iso_code = models.CharField(max_length=3, null=False)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, null=False)

    work_shift = models.IntegerField(null=False, blank=False)
    work_period = models.IntegerField(null=False, blank=False)

    created_on = models.DateTimeField(default=datetime.now)

    def __str__(self):
        return f'RegisteredPayment({self.user.username}, {self.fare_product_id}, date={self.created_on})'


class PrintedReceipts(models.Model):
    user = models.ForeignKey(User, null=True, on_delete=CASCADE)
    job_data = models.CharField(blank=False, null=False, max_length=5000)
    job_type = models.CharField(blank=False, null=False, max_length=40)
    created_on = models.DateTimeField(default=datetime.now)

    def __str__(self):
        return f'PrintedReceipts({self.user.username if self.user else "Anonymous"}, ' \
               f'job_type={self.job_type}, date={self.created_on})'
