from django.db import models

from .consts import GATE_MODE_CHOICES


class TicketingGateMode(models.Model):
    mode = models.CharField(max_length=50, null=False, blank=False, choices=GATE_MODE_CHOICES)
