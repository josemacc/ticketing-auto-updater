from datetime import datetime
from django.db import models


class SecureMessage(models.Model):
    message_type = models.CharField(blank=False, null=False, max_length=100)

    message_id = models.UUIDField(primary_key=True, unique=True)
    node_id = models.CharField(blank=False, null=False, max_length=100)
    parent_site_id = models.CharField(blank=False, null=False, max_length=100)
    company_id = models.CharField(blank=False, null=False, max_length=100)

    employee_id = models.CharField(blank=False, null=False, max_length=100)
    work_shift = models.IntegerField(null=False)
    work_period = models.IntegerField(null=False)

    json_payload = models.CharField(max_length=4000)
    created_on = models.DateTimeField(default=datetime.now)
