from django.db import models


class TransitCounter(models.Model):
    mode = models.CharField(primary_key=True, max_length=50, unique=True)
    counter = models.IntegerField(default=0)
