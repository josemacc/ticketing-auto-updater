import json
import re
import os
import tempfile
from jsmin import jsmin

# Format when parsing datetime strings into datetime objects, eg: 2021-08-25 14:56:12
DATE_TIME_FORMAT = '%Y-%m-%d %H:%M:%S'

VARIABLE_PATTERN = re.compile(r'^([A-Za-z][A-Za-z0-9_]*)')
NUMBER_PATTERN = re.compile(r'^([0-9.]+)')
OPERATOR_PATTERN = re.compile(r'^\s*([><=!]{1,2})\s*')
STRING_PATTERN = re.compile(r"^'(.*)'")
VALUE_IDX_OPERAND_1 = 0
VALUE_IDX_OPERATOR = 1
VALUE_IDX_OPERAND_2 = 2

OPERATOR_FUNCTIONS = {
    '==': lambda x, y: x == y,
    '>=': lambda x, y: x >= y,
    '<=': lambda x, y: x <= y,
    '>': lambda x, y: x > y,
    '<': lambda x, y: x < y,
    '!=': lambda x, y: x != y,
}


# Valid variable types to provide as the use_template_context parameter for "load_json"
ALLOWED_TEMPLATE_VARS = (None, list, tuple)


def load_json(config, use_template_context=None, required_template_vars=None):
    """
    Load a json content and return the represented Python object (dict, array, str, etc.).

    :param config: str|object.  If str, it is the filename to load, otherwise the same
           object is returned (as it is a Python object already)
    :param use_template_context: None|dict.  If provided and "config" is a filename, the keys/values in this
           dictionary will available as variables in the template. To use a variable or expression in the context, do:
           {{EXPRESSION}}
           The expression can take either of these two forms:
              VARIABLE|VALUE
              VARIABLE|VALUE operator VARIABLE|VALUE
              operator can be any of:
                    equal: ==
                    greater than: >
                    less than: <
                    greater or equal than: >=
                    less or equal than: <=
                    different: !=

           The rules to define variables and values are:
              - The text is considered a VARIABLE if it appears without quotes and starts with an alphabetic character
              - The text is considered a VALUE if it appears in quotes, or it is a numeric value
              - Any other combination is an error and the configuration is not loaded
              - The only variables available are the ones passed in the use_template_context parameter

           Examples:
              # The active status will be "1" if DEVICES_MOD_READER equals to "serial", otherwise it will get "0"
              "active": "{{DEVICES_MOD_READER == 'serial'}}"

              # The url will be the value specified on the variable UPDATES_URL
              "url": "{{UPDATES_URL}}"

              # The timeout_1 will get value 10  (an integer)
              "timeout_1": "{{10}}"

              # The timeout_2 will get value "10"  (a string)
              "timeout_2": "{{'10'}}"

              # The timeout_3 will get value 30  (an integer)
              "timeout_3": 30

    :param required_template_vars: list|tuple. A list of variable names that must exist if they are referenced in
           the context. If a listed variable is used in the template, but it doesn't exist, an exception is raised.
    :return: dict|list|str, depending on the json content read
    """
    var_type = None if required_template_vars is None else type(required_template_vars)
    if var_type not in ALLOWED_TEMPLATE_VARS:
        allowed_str = ', '.join(f'{t if t is None else t.__name__}' for t in ALLOWED_TEMPLATE_VARS)
        raise ValueError(f'required_template_vars must be any of "{allowed_str}". '
                         f'Provided value is a "{var_type.__name__}"')

    if type(config) == str:
        with open(config, 'rt') as f:
            json_str = jsmin(f.read())
            if type(use_template_context) == dict:
                context_var_names = use_template_context.keys()

                while True:
                    start_idx = json_str.find('"{{')
                    if start_idx >= 0:
                        start_idx3 = start_idx + 3
                        end_idx = json_str.find('}}"', start_idx3)
                        if end_idx <= start_idx:
                            raise ValueError(f'Invalid template variable at position {start_idx}')

                        template_expression_ref = json_str[start_idx:end_idx + 3]

                        # Read the expression
                        original_expression = expression = (json_str[start_idx3:end_idx]).strip()
                        if not expression:
                            raise ValueError(f'Invalid template variable at position {start_idx3}')

                        values = [None, None, None]
                        value_idx = VALUE_IDX_OPERAND_1

                        while True:
                            if value_idx in (VALUE_IDX_OPERAND_1, VALUE_IDX_OPERAND_2):
                                # Pick an Operand
                                as_str = STRING_PATTERN.match(expression)
                                as_number = NUMBER_PATTERN.match(expression)
                                as_variable = VARIABLE_PATTERN.match(expression)

                                if as_str:
                                    values[value_idx] = as_str[0][1:-1]
                                    expression = expression[as_str.span()[1]:]

                                elif as_number:
                                    try:
                                        values[value_idx] = int(as_number[0])
                                        expression = expression[as_number.span()[1]:]
                                    except Exception:
                                        raise ValueError(f'Invalid expression "{original_expression}" '
                                                         f'reading the configuration')

                                elif as_variable:
                                    var_name = as_variable[0]

                                    # Make sure the var is provided if it is required to
                                    if required_template_vars and \
                                            len(list(
                                                [v for v in required_template_vars if var_name.startswith(v)])) > 0:

                                        if var_name not in context_var_names:
                                            raise ValueError(f'Required variable "{var_name}" '
                                                             f'not provided in the context')

                                    values[value_idx] = use_template_context.get(var_name)
                                    expression = expression[as_variable.span()[1]:]

                                else:
                                    raise ValueError(f'Invalid expression "{original_expression}" '
                                                     f'reading the configuration')

                                if expression == '':
                                    break

                            else:
                                # Pick the Operator
                                as_operator = OPERATOR_PATTERN.match(expression)
                                if as_operator:
                                    operator = as_operator[0].strip()
                                    values[value_idx] = operator
                                    expression = expression[as_operator.span()[1]:]
                                else:
                                    raise ValueError(f'Invalid operator in the expression "{original_expression}" '
                                                     f'reading the configuration')

                            value_idx += 1
                            if value_idx >= 3 and expression != '':
                                raise ValueError(f'Invalid expression "{original_expression}" '
                                                 f'reading the configuration')

                        # Expression read, now evaluate it

                        if value_idx == 0:
                            # The expression is a single value
                            value = values[0]
                        else:
                            # The expression is like "value1 <operator> value2"
                            try:
                                op_function = OPERATOR_FUNCTIONS.get(values[1])
                                if callable(op_function):
                                    value = op_function(values[0], values[2])
                                else:
                                    raise Exception(f'Unknown operator "{values[1]}"')

                            except Exception as e:
                                raise ValueError(f'Invalid expression "{original_expression}" '
                                                 f'reading the configuration. Inner exception is: {e}')

                        value = json.dumps(value)
                        json_str = json_str.replace(template_expression_ref, f'{value}')

                    else:
                        # No more variables to replace on json_str
                        break

            return json.loads(json_str)

    return config


def replace_params(s, params):
    result = s
    if s and params and type(params) == dict:
        for k, v in params.items():
            src = '{' + k + '}'
            if src in result:
                result = result.replace(src, str(v))

    return result


# noinspection PyBroadException
def dir_is_writable(dir_path, make_dir=False):
    """
    Test if a directory path is writable by this application.

    :param dir_path: str. The directory path
    :param make_dir: bool. If True, the function will attempt to create any intermediate directory
    :return: bool. True if the directory is writable (and intermediate directories were created as well, if requested)
             False, otherwise
    """
    if dir_path:
        if make_dir:
            try:
                os.makedirs(dir_path, exist_ok=True)
            except Exception:
                return False

        if os.path.isdir(dir_path):
            try:
                tmp_file = tempfile.TemporaryFile(dir=dir_path)
                tmp_file.close()
                return True
            except Exception:
                pass

    return False


def intersection(lst1, lst2):
    """
    Return the intersection between two lists.

    :param lst1: list|tuple|set. The first of the lists
    :param lst2: list|tuple|set. The second of the lists
    :return: list. A list containing the elements that are common to both lists
    """
    if type(lst1) == set and type(lst2) == set:
        return list(set(lst1) & set(lst2))
    else:
        return [x for x in lst1 if x in lst2]


def only_keys(src_dict, keys):
    """
    Returns a dictionary like the one in src_dict but only including the provided keys.

    :param src_dict: dict. The source dictionary
    :param keys: list|tuple. The list of keys to filter by
    :return: dict. A new dictionary as src_dict but having only the keys specified in keys
    """
    if not src_dict:
        return src_dict

    result = {}
    for k, v in src_dict.items():
        if k in keys:
            result[k] = v

    return result


def except_keys(src_dict, keys):
    """
    Returns a dictionary like the one in src_dict but excluding the provided keys.

    :param src_dict: dict. The source dictionary
    :param keys: list|tuple. The list of keys to filter by
    :return: dict. A new dictionary as src_dict but having only the keys *not* specified in keys
    """
    if not src_dict:
        return src_dict

    result = {}
    for k, v in src_dict.items():
        if k not in keys:
            result[k] = v

    return result


def remove_fields(dict_obj, fields):
    if type(dict_obj) == dict and type(fields) in (list, tuple) and len(fields):
        for f in fields:
            if f in dict_obj.keys():
                del dict_obj[f]


def look_up_in_list_of_dict(iter_list, key, value):
    """
    Look up a dict-like item in an array by a specified value.
    Example:
    data = [{"a": 1, "b: "Foo"}, {"a": 5, "b: "Bar"}, {"a": 10, "b: "other"}]

    print( look_up_in_list_of_dict(data, "a", 5) )

    Output:
    {"a": 5, "b: "Bar"}

    :param iter_list: list|tuple. The array of items to look in
    :param key: str. The key to look up in each item
    :param value: object. The value to look for
    :return: object. The first item having the key=value pair being looked up. None, if not found
    """
    if type(iter_list) in (list, tuple):
        for item in iter_list:
            if type(item) == dict and (key in item.keys()) and item.get(key) == value:
                return item

    return None


def list_without_duplicates(src_list):
    """
    Remove duplicate items from a list.

    :param src_list: list|tuple. The original list having all items, potentially duplicated
    :return: list. The list having the same items as in src_list without duplicates
    """
    result = []

    if src_list:
        for i in src_list:
            if i not in result:
                result.append(i)

    return result


def wipe_white_spaces(string):
    """
    Remove white spaces from param string.
    """
    return string.replace(" ", "")
